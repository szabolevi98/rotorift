import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {filmRotorMotion,filmShutterSeconds,PLANE_SHUTTER_SAMPLES} from './propeller-exposure.js';
import {pathToFileURL} from 'node:url';
const repo=pathToFileURL((process.env.ROTORIFT_ROOT??'D:/xampp/htdocs/rotorift')+'/data/');
for(const [kind,id]of [['drones','rift-x5'],['drones','rift-c3'],['airplanes','rift-t15'],['drones','rift-65'],['drones','rift-r5']]){
 const config=JSON.parse(await readFile(new URL(`${kind}/${id}.json`,repo),'utf8'));
 const fractions=config.kind==='fixedWing'?[.68]:[.55,.56,.55,.57];
 test(id+': shutter matches each aircraft, phase is absolute and motor directions agree',()=>{
  const first=filmRotorMotion(config,1,fractions),next=filmRotorMotion(config,1+1/60,fractions);
  assert.equal(first.length,config.motors.length);
  for(let i=0;i<first.length;i++){
   assert.ok(first[i].rpm>7000&&first[i].rpm<60000);
   if(config.kind==='fixedWing'){assert.ok(first[i].exposureTurns>0&&first[i].exposureTurns<.1);assert.equal(PLANE_SHUTTER_SAMPLES,32);}else assert.ok(first[i].exposureTurns>1,'full-turn rotational mean is valid for quad rotors');
   assert.equal(Math.sign(first[i].angularSpeed),config.motors[i].direction);
   assert.ok(Math.abs(next[i].phase-first[i].phase-first[i].angularSpeed/60)<1e-9);
   assert.ok(Math.abs(first[i].exposureTurns-first[i].rpm/60*filmShutterSeconds(config))<1e-12);
  }
  filmRotorMotion(config,7,fractions);
  assert.deepEqual(filmRotorMotion(config,1,fractions),first);
 });
 test(id+': stopped rotors have zero sweep and invalid load cannot exceed the configured limit',()=>{
  const stopped=filmRotorMotion(config,8,Array(config.motors.length).fill(0));
  assert.ok(stopped.every(r=>r.angularSpeed===0&&r.rpm===0&&r.exposureTurns===0));
  assert.deepEqual(filmRotorMotion(config,1,Array(config.motors.length).fill(2)),filmRotorMotion(config,1,Array(config.motors.length).fill(1)));
 });
}
