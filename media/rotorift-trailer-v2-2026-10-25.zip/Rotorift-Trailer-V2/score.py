"""Original 49-second instrumental and synthesized aircraft sound design."""
import numpy as np
import wave
from pathlib import Path

SR=48000
DURATION=49
N=SR*DURATION
rng=np.random.default_rng(198)
mix=np.zeros((N,2),np.float64)

def note(midi): return 440*2**((midi-69)/12)
def add(start,sound,amp=1,pan=0):
    i=int(start*SR)
    if i<0: sound=sound[-i:];i=0
    n=min(len(sound),N-i)
    if n<=0:return
    if sound.ndim==1:
        mix[i:i+n,0]+=sound[:n]*amp*np.sqrt((1-pan)/2)
        mix[i:i+n,1]+=sound[:n]*amp*np.sqrt((1+pan)/2)
    else:mix[i:i+n]+=sound[:n]*amp

def pluck(midi,duration=.6):
    t=np.arange(int(SR*duration))/SR;f=note(midi)
    env=(1-np.exp(-t*450))*np.exp(-t*7.5)
    wave=np.sin(2*np.pi*f*t)+.3*np.sin(2*np.pi*2*f*t)*np.exp(-t*7)+.12*np.sin(2*np.pi*3*f*t)*np.exp(-t*11)
    return wave*env

def bass(midi,duration=.22):
    t=np.arange(int(SR*duration))/SR;f=note(midi)
    env=np.minimum(t/.006,1)*np.minimum((duration-t)/.045,1)*np.exp(-t*2)
    osc=np.sin(2*np.pi*f*t)+.35*np.sin(4*np.pi*f*t)+.12*np.sin(6*np.pi*f*t)
    return np.tanh(osc*1.2)*env

def kick():
    t=np.arange(int(.45*SR))/SR
    frequency=46+120*np.exp(-t*35)
    phase=np.cumsum(frequency)*2*np.pi/SR
    return np.sin(phase)*np.exp(-t*12)*(1-np.exp(-t*1800))+.08*rng.normal(size=len(t))*np.exp(-t*220)

def snare():
    t=np.arange(int(.23*SR))/SR
    n=rng.normal(size=len(t));n=n-np.convolve(n,np.ones(11)/11,mode='same')
    return .45*n*np.exp(-t*24)+.25*np.sin(2*np.pi*178*t)*np.exp(-t*28)

def hat(opened=False):
    duration=.19 if opened else .075;t=np.arange(int(duration*SR))/SR
    n=rng.normal(size=len(t));n=n-np.convolve(n,np.ones(7)/7,mode='same')
    return n*np.exp(-t*(22 if opened else 65))*(1-np.exp(-t*2000))

roots=[38,34,41,36]
chords=[[62,65,69,72],[58,62,65,69],[60,65,69,72],[60,64,67,74]]
# Warm stereo pads, no samples or external music.
for block in range(12):
    start=block*4;dur=4.8;t=np.arange(int(dur*SR))/SR
    envelope=np.minimum(t/.65,1)*np.minimum((dur-t)/1.2,1)*.5*np.clip((45-start-t)/.4,0,1)
    pad=np.zeros((len(t),2))
    for j,midi in enumerate(chords[block%4]):
        f=note(midi-12)
        for ch,detune in enumerate([-.0012,.0012]):
            pad[:,ch]+=(np.sin(2*np.pi*f*(1+detune)*t+j)+.13*np.sin(4*np.pi*f*(1+detune)*t+j))*envelope
    add(start,pad,.035)

# Four-on-the-floor pulse, syncopated low synth and an original pentatonic hook.
melody=[74,77,81,77,72,74,69,72,74,77,81,84,81,77,74,72]
for beat in range(90):
    sec=beat*.5
    add(sec,kick(),.44)
    if beat%4 in [1,3]:add(sec,snare(),.24)
    add(sec,hat(),.052,pan=-.27)
    add(sec+.25,hat(beat%4==3),.045,pan=.32)
    block=int(sec//4)
    root=roots[block%4]
    add(sec+.125,bass(root,.23),.23)
    if beat%4 in [0,2,3]:add(sec+.375,bass(root+(12 if beat%4==3 else 0),.105),.11)
    if beat%2==0 or beat>=54:
        midi=melody[(beat//2)%len(melody)]
        # Slightly quieter in the spacious Liget scene.
        amp=.078 if 9<=sec<18 else .095
        p=(-.22 if beat%4==0 else .22)
        sound=pluck(midi,.65)
        add(sec+.25,sound,amp,p)
        add(sec+.625,sound,amp*.25,-p)
        add(sec+1,sound,amp*.12,p)

# Chapter transitions: short stereo air sweeps, without obscuring the engines.
for cut in [9,18,27,36,45]:
    dur=.65;t=np.arange(int(dur*SR))/SR
    n=rng.normal(size=len(t));n=np.convolve(n,np.ones(19)/19,mode='same')
    env=np.sin(np.pi*t/dur)**2
    stereo=np.stack([n*env*(1-t/dur),n*env*t/dur],axis=1)
    add(cut-.45,stereo,.20)
    add(cut,pluck(38,1.3),.18)

# Aircraft layers follow each airframe's actual acoustic profile from the game.
profiles=[(530,.52,3,.032),(760,.30,3,.025),(180,.70,2,.027),(1400,.12,3,.021),(590,.40,3,.032)]
for i,(rotor_hz,body,blades,amp) in enumerate(profiles):
    t=np.arange(9*SR)/SR
    load=.55+.035*np.sin(t*1.8)+.02*np.sin(t*4.1)
    freq=rotor_hz*(.24+.76*load)
    phase=np.cumsum(freq)*2*np.pi/SR
    sound=body*np.sin(phase)
    for h in range(1,5):sound+=np.sin(phase*blades*h)/(h**1.65)*.45
    noise=rng.normal(size=len(t));air=np.convolve(noise,np.ones(15)/15,mode='same')
    sound=sound*.75+air*.22
    envelope=np.minimum(t/.25,1)*np.minimum((9-t)/.18,1)
    add(i*9,sound*envelope,amp,pan=-.08)

# Resolve into the brand card with a spacious D minor chord and sub impact.
for j,midi in enumerate([50,57,62,65,69,74]):
    s=pluck(midi,4)
    add(45,s,.12 if j<2 else .075,pan=(j-2.5)/5)
    add(45.375,s,.025,pan=-(j-2.5)/5)

# Gentle saturation, final fade and safe headroom before the mastering pass.
mix=np.tanh(mix*1.12)
fade=np.minimum(np.arange(N)/(.18*SR),1)*np.minimum((N-1-np.arange(N))/(.5*SR),1)
mix*=fade[:,None]
mix*=.87/max(.87,np.max(np.abs(mix)))
out=Path(__file__).parent/'score.wav'
with wave.open(str(out),'wb') as wav:
    wav.setnchannels(2);wav.setsampwidth(2);wav.setframerate(SR)
    wav.writeframes((mix*32767).astype('<i2').tobytes())
print(out)
print('peak',np.max(np.abs(mix)),'rms',np.sqrt(np.mean(mix**2)))
