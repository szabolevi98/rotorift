# Rotorift trailer – újra-előállítási leírás

Rögzítve: 2026-10-25. Ez a **javított záróképes és propellerelmosásos** angol trailer
leírása. A hozzá tartozó `Rotorift-Video-Reproduction.zip` csomag a
renderforrást, a rögzített függőségeket és az elfogadott videó összeállításához
szükséges médiaelemeket is tartalmazza. A csomagot és ezt a fájlt együtt őrizd meg.

## Mi reprodukálható?

- **Az elfogadott kép és hang pontos visszaállítása:** a csomagban lévő kész
  videósávokból és hangsávból, újabb veszteséges tömörítés nélkül.
- **Új render a játékból:** ugyanazokkal az útvonalakkal, kamerával, modellekkel,
  feliratokkal és zenével. A GPU, a driver, a Chrome és a kódoló verziója
  okozhat pixel- vagy fájlszintű eltérést. A teljes MP4 fájl bájtpontos egyezését
  ez a módszer nem ígéri.

A videó a játék valódi pályáit és modelljeit használó, tervezett kamerás animáció.
Nem kézzel, a játék fizikájával végigrepült vagy generatív videó.

## Rögzített játékverzió

- Repo: `https://github.com/szabolevi98/rotorift.git`
- Commit: `3adab810dff5653591e58a29186c1740e1f6ee14`
- A commit tartalmazza a tornatermi korlát és a kikötői daruk javítását,
  valamint a közös látótávolság-beállítást.
- Eredeti helyi repo: `D:\xampp\htdocs\rotorift`.
- Eredeti render-munkamappa:
  `C:\Users\Levente\Documents\Codex\2026-10-25\s\work\trailer`.
- Elfogadott végleges fájl: `Rotorift-Trailer-English-Final-v2-1080p60.mp4`.
- Az eredeti MP4, a források és a médiaelemek SHA-256 értékei: `manifest.json`.

## Vágás és tartalom

| Idő | Pálya | Gép | Jelenet |
| --- | --- | --- | --- |
| 0–9 s | Apex Circuit (`apex`) | Rift X5 (`rift-x5`) | Kék autó követése; az előrébb haladó autó narancs |
| 9–18 s | Grove / Liget (`liget`) | Rift C3 (`rift-c3`) | Átrepülés a középső pavilon alatt |
| 18–27 s | Skyline (`skyline`) | Rift Aero 150 (`rift-t15`) | 1500 mm-es repülő a házak között, forgó légcsavarral |
| 27–36 s | Gymnasium (`gym`) | Rift 65 (`rift-65`) | Tornatermi átrepülés |
| 36–45 s | Harbor (`harbor`) | Rift R5 (`rift-r5`) | Nyitott konténer, darukapu, hajó |
| 45–49 s | Zárókép | Rotorift logó | Webcím és angol feliratok |

Kimenet: **49 s, 1920×1080, valódi 60 fps, 2940 képkocka**, H.264 High,
AAC stereo 48 kHz, 16:9. A végső videó BT.709, korlátozott jeltartományú
`yuv420p`. A zenét, a motorhangokat és az átvezető suhintásokat a `score.py`
szintetizálja; a véletlengenerátor rögzített magja `198`.

## 1. Az elfogadott videó gyors visszaállítása

Csomagold ki a ZIP-et egy saját mappába, majd PowerShellben lépj oda.
Ehhez a módszerhez **nem kell játék, Chrome vagy adatbázis**, csak Python és FFmpeg.

```powershell
python -m pip install imageio-ffmpeg==0.6.0
python assemble.py
```

Kimenet: `generated\Rotorift-Approved-Reassembled-1080p60.mp4`.
Az összeszerelő újrakódolás nélkül összefűzi a `reference\flights.mp4`
45 másodpercét a `reference\end.mp4` 4 másodpercével, és hozzáadja a
`reference\audio.m4a` hangsávot. Végigdekódolja az eredményt, ellenőrzi
a 2940 képkockát, majd az elfogadott teljes videó H.264 képadatai és AAC
hangadatai lenyomatával
hasonlítja össze. Mindkét ellenőrzésnek `MATCHES APPROVED` eredményt kell adnia.
Az MP4 konténer metaadatai eltérhetnek, a másolt H.264 és AAC tartalom egyezik.

Ezt a gyors visszaállítást a csomag elkészítésekor végig ellenőriztem:
a teljes 49 másodperces H.264 képanyag és az AAC tartalom lenyomata is egyezett.
A `score.py` újragenerált WAV-ja bájtra egyezett a mentett hanggal.
A propellerelmosás a külön filmrenderelő része; az élő játék kódját és
fizikáját nem módosítja. A fordulat-, forgásirány- és időbeli
megismételhetőségi ellenőrzések a `test-propeller-exposure.mjs` fájlban vannak.

## 2. Teljes újrarenderelés a játékból

Az eredeti környezet: Windows, Node **24.19.0**, Python **3.10.11**,
Chrome **156.0.8078.47**, FFmpeg **7.1**, Playwright Core **1.64.1**.
A Python-függőségek a `requirements.txt`, a Node-függőség a `package-lock.json`
fájlban rögzített. Több GB szabad hely kell a veszteségmentes PNG képkockákhoz.

### Játékforrás előkészítése

A meglévő, esetleg módosított játékot ne állítsd vissza. Készíts külön klónt:

```powershell
git clone https://github.com/szabolevi98/rotorift.git rotorift-render-source
git -C rotorift-render-source checkout --detach 3adab810dff5653591e58a29186c1740e1f6ee14
npm ci --prefix rotorift-render-source
```

Ezután a kicsomagolt reprodukciós csomag gyökerében:

```powershell
npm ci
python -m pip install -r requirements.txt
$env:ROTORIFT_ROOT = (Resolve-Path .\rotorift-render-source).Path
$env:CHROME_PATH = 'C:\Program Files\Google\Chrome\Application\chrome.exe'
$env:FILM_FFMPEG = python -c "import imageio_ffmpeg; print(imageio_ffmpeg.get_ffmpeg_exe())"
node server.mjs
```

Ha máshol van a klón vagy a Chrome, az elérési utakat igazítsd hozzá.
A szerver csak a `127.0.0.1:3198` címen szolgálja ki a renderoldalt és a játék
statikus fájljait; nem indít éles játékszervert és nem használ adatbázist.
Hagyd futni ezt a terminált.

### Renderelés egy második PowerShell-terminálban

Lépj ugyanabba a kicsomagolt mappába, majd:

```powershell
$env:CHROME_PATH = 'C:\Program Files\Google\Chrome\Application\chrome.exe'
$env:FILM_FFMPEG = python -c "import imageio_ffmpeg; print(imageio_ffmpeg.get_ffmpeg_exe())"
node render.mjs
node render-endcard.mjs
python score.py
python assemble.py --fresh
```

A `render.mjs` jelenetenként 540 PNG-t és `media\scene-0.mp4` …
`media\scene-4.mp4` fájlokat ír. A `render-endcard.mjs` a külön, jobb minőségű
záróképet készíti. A `score.py` újra létrehozza a 49 másodperces `score.wav`
hangot. Az összeszerelő elkészíti a repülős részek BT.709 mesterét, a normalizált
AAC hangsávot, majd újabb videótömörítés nélkül hozzáfűzi a záróképet.

Kimenet: `generated\Rotorift-Rerendered-1080p60.mp4`.
Ellenőrzési napló: `generated\verification.txt`.
A végén `Verified: 49 seconds, 2940 frames, audio + video decode OK` kell megjelenjen.

Ha csak a képet változtatod, a korábbi AAC hangsávot pontosan megtartó változat: `python assemble.py --fresh --copy-audio`.
A propellerelmosás tesztjei: `node --test test-propeller-exposure.mjs` (a `ROTORIFT_ROOT` változó itt is a játékforrásra mutasson).

Gyors próba, jelenetenként egyetlen PNG-vel: `node render.mjs --smoke`.
Egyetlen jelenet újrarenderelése: például `node render.mjs --chapter=4` a kikötőhöz.
A `--fresh` összeszereléshez mind az öt jelenet és a zárókép szükséges.
A render végén a szerver termináljában `Ctrl+C`-vel leállítható a helyi kiszolgáló.

## Megőrzendő részletek és korábbi hibák

- A `trailer.js` tartalmazza az eredeti útvonalakat, a 240 Hz-en simított mozgást,
  a kamerát, az angol feliratokat, az autók színcseréjét és a teljes zárókép rajzát.
  A csomagban ez a tényleges végleges forrás változatlan másolata.
- Az Apex autóforgalmának ideje `2+t`, magja `0`. Csak a két karosszéria színe
  cserélődik, a jelenet mozgását nem szabad újra megtervezni.
- A repülő `rift-t15`, nem `rift-a40`. A propeller fázisa az abszolút
  jelenetidőből számolódik, a motorvezérlés `.68`.
- A propellereket a `propeller-exposure.js` kezeli, a játék lassított
  megjelenítőjét felülírva kizárólag a filmben. A típushoz tartozó becsült
  lapátcsúcssebességből (`maxTipSpeedMps`), propellersugárból és a
  normalizált motorfordulatból számol: `omega = tipSpeed / radius × fraction`.
  A forgásirány a gépkonfigurációt követi, a fázis az abszolút jelenetidőből
  származik, ezért tetszőleges időpontra ugráskor megismételhető.
  A drónok motorértékei `[.55,.56,.55,.57]`, a repülőé `.68`.
- A becsült fordulat X5: 12,4–12,9 ezer, C3: 20,7–21,5 ezer,
  Rift 65: 50,8–52,7 ezer, R5: 12,8–13,3 ezer, Aero 150: 7,67 ezer
  fordulat/perc. Ezek a játék modelljéből származó értékek, nem gyári mérések.
- A kimenet 60 fps. A drónok 1/120 s expozíciót és a valódi lapátgeometriából
  képzett teljes forgási átlagot használnak: 256 sugárminta, mintánként 1536 szög.
  A repülő 1/2000 s expozíciója ehelyett 32 időmintából rajzolja a két valódi
  lapát elmosódott ívét. Ez megtartja a látható légcsavarformát, miközben a
  becsült fordulat és az abszolút fázis változatlan. A rövid expozíció alatt
  körülbelül 23 fokot fordul a repülő propellere. A motorok, agyak, védőkeretek
  és a géptest éles, mélységtesztelt geometriák maradnak. Ez filmes expozíciós
  közelítés; a minták áttetsző rajzolását nem teljes optikai szimulációként kezeljük.
- A drón az FPV-közelítéskor két teljesen mélységtesztelt kép összekeverésével
  tűnik el. Az egyes anyagok átlátszóságának állítgatása eltüntetné az alkatrészeket.
- A kültéri kamerák a játék `mapViewDistance()` beállítását használják:
  általában 12 km, kikötő 18 km, tornaterem 180 m. A korábbi, 2200 m-es
  exportbeállítás levágta a távoli hegyeket és villódzó sziluettet okozott.
- A zárókép sötét színátmenete statikus, finom dithert kap. Kódolása külön
  történik: x264 `CRF 12`, `tune grain`, közvetlen RGB → BT.709 átalakítással.
  Ezt ne vezesd vissza a repülős részek kétszeres kódolási láncába.
- A köztes jelenetek teljes tartományú BT.601 képek (`yuvj420p`, `pc`);
  a végső repülős mester korlátozott tartományú BT.709. Az átalakításokat
  ne hagyd el és ne ismételd meg önkényesen, mert megváltozhatnak a színek.
- A régi PNG/JPEG csővezetékes export néha hibás képkockákat adott. A csomag
  renderelője külön PNG-fájlokat ír, és a kódoló dekódolási hibánál leáll.
- A csomag nem tartalmaz `node_modules` könyvtárat, titkokat vagy adatbázist.
  A játék forrását a fenti commitból kell beszerezni.

## A propelleres változat ellenőrzése

A csomagolt renderelővel mind az öt jelenet teljes 540 képkockája elkészült.
A típusonkénti fordulat, a forgásirány és az abszolút fázis 10 tesztje sikeres.
A drónok útvonal-, simítás-, kamera- és záróképforrása egyezik az előző változattal. A repülő kezdeti követőkamerája alacsonyabbról néz a légcsavarra.
A teljes 49 másodperc szigorú dekódolási ellenőrzése sikeres, összesen 2940
képkockával. Az AAC hangsáv és mind a 240 záróképkocka lenyomata változatlan.
A tényleges rotoradatok a `reference/rotor-exposure-checks.json` fájlban vannak.

## Hol kell később változtatni?

| Feladat | Fájl |
| --- | --- |
| Útvonal, kamera, jelenetfelirat, háttér, zárókép | `trailer.js` |
| Játékforrás / Chrome elérési út | Környezeti változók vagy `config.mjs` |
| Zene, motorhang, jelenetváltási suhintás | `score.py` |
| Repülős képkockák és köztes kódolás | `render.mjs` |
| Propellerfordulat és geometria alapú elmosódás | `propeller-exposure.js` |
| Zárókép kódolása | `render-endcard.mjs` |
| Összeállítás, hangnormalizálás, ellenőrzés | `assemble.py` |
| A tényleges pálya vagy gép javítása | Rotorift játékforrás; utána render |

A YouTube leírásában szereplő öt helyszín csak a trailer válogatása:
**“Five flights. Five locations. Just a taste of Rotorift.”** A játékban
további pályák és repülhető gépek is vannak.

## Elmentett YouTube-borító

A csomag `cover` mappája a jóváhagyott OG-borító YouTube-hoz újraalkotott
változatát is tartalmazza:

- `Rotorift-OG-YouTube-recreated-master.png`: a megőrzendő teljes PNG mester.
- `Rotorift-OG-YouTube-recreated-1280x720.jpg`: a kész YouTube-bélyegkép.
- `Rotorift-OG-YouTube-recreation-prompt.txt`: az átdolgozás pontos utasításai.
- `Rotorift-original-OG-cover-notes.md`: az eredeti OG-kép készítési leírása.
- `Rotorift-original-OG-reference.png`: az átdolgozáshoz használt eredeti OG-kép.

A PNG mestert és a kész JPG-t közvetlenül használd, ha ugyanaz a borító kell.
A promptból történő ismételt képgenerálás nem garantál azonos pixeleket.
A mentett fájlok sértetlensége a `manifest.json` SHA-256 értékeivel ellenőrizhető.

## V2: láthatóbb légcsavar és egységes játékbeli elmosás

A legutóbbi módosítás csak a 18–27. másodperc repülős jelenetét renderelte újra.
A repülő kezdeti követőkamerájának magassága 0,9 m helyett 0,2 m, hogy a szárny kevésbé takarja a légcsavart. A repülési útvonal és az FPV-átmenet időzítése megmarad.
A másik négy jelenet és mind a 240 záróképkocka dekódolt lenyomata egyezik az
előző változattal; az AAC hangsáv változatlan. A rövid repülőexpozíció adatai
a `reference/plane-shutter-checks.json` fájlban találhatók. A mentett anyagokból
történő visszaállítás az új V2 fájlt állítja össze.

A játék FPV és külső nézetének elmosási görbéje külön javításként, a
`bfb67b7` commitban lett azonosítva (42 sikeres teszt). A videó újrarendereléséhez
továbbra is a dokumentum elején rögzített pálya- és modellverzió használható.
