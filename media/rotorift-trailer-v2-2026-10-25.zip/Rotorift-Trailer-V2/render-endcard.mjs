import {chromium} from 'playwright-core';
import {mkdir} from 'node:fs/promises';
import {spawnSync} from 'node:child_process';
import {base,chrome,url} from './config.mjs';
const dir=base+'/frames/end';await mkdir(dir,{recursive:true});await mkdir(base+'/media',{recursive:true});
const browser=await chromium.launch({executablePath:chrome,headless:true});
try{
  const page=await browser.newPage({viewport:{width:1920,height:1080},deviceScaleFactor:1});
  page.on('pageerror',e=>{throw e;});
  await page.goto(url);await page.waitForFunction(()=>window.filmReady);
  for(let f=0;f<240;f++){
    await page.evaluate(t=>window.renderFilm(t),45+f/60);
    await page.screenshot({path:`${dir}/frame-${String(f).padStart(4,'0')}.png`,type:'png'});
    if(f%60===0)console.log('ENDCARD',f);
  }
}finally{await browser.close();}
const encoder=spawnSync(process.env.FILM_FFMPEG,['-y','-hide_banner','-loglevel','warning','-xerror','-err_detect','explode','-framerate','60','-i',dir+'/frame-%04d.png','-frames:v','240','-an','-vf','scale=in_range=full:out_range=limited:out_color_matrix=bt709,format=yuv420p,setsar=1','-c:v','libx264','-preset','medium','-tune','grain','-crf','12','-profile:v','high','-level:v','4.2','-color_range','tv','-colorspace','bt709','-color_primaries','bt709','-color_trc','bt709','-video_track_timescale','15360','-movflags','+faststart',base+'/media/end.mp4'],{windowsHide:true,stdio:'inherit'});
if(encoder.error)throw encoder.error;if(encoder.status)throw Error('Endcard encode failed');
