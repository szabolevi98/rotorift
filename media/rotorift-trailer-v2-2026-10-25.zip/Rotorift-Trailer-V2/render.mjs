import {chromium} from 'playwright-core';
import {mkdir,writeFile} from 'node:fs/promises';
import {spawnSync} from 'node:child_process';
import {base,chrome,chromeArgs,url} from './config.mjs';
const option=process.argv.find(arg=>arg.startsWith('--chapter='));
const chapter=option?Number(option.split('=')[1]):null;
if(chapter!==null&&(!Number.isInteger(chapter)||chapter<0||chapter>4))throw Error('Chapter must be 0..4');
const smoke=process.argv.includes('--smoke');
const browser=await chromium.launch({executablePath:chrome,headless:true,args:chromeArgs});
try{
  const page=await browser.newPage({viewport:{width:1920,height:1080},deviceScaleFactor:1});
  const cdp=await page.context().newCDPSession(page);
  page.on('pageerror',e=>{throw e;});
  await page.goto(url);await page.waitForFunction(()=>window.filmReady,undefined,{timeout:120000});
  await mkdir(base+'/media',{recursive:true});
  for(let i=0;i<5;i++){
    if(chapter!==null&&chapter!==i)continue;
    const loaded=await page.evaluate(i=>window.loadChapter(i),i);console.log('LOAD',i,loaded);
    if(i===2)console.log('CAMERA',await page.evaluate(()=>window.filmDiagnostics()[2]));
    const dir=base+`/frames/chapter-${i}`;await mkdir(dir,{recursive:true});
    for(let f=0;f<(smoke?1:540);f++){
      await page.evaluate(t=>window.renderFilm(t),i*9+f/60);
      const shot=await cdp.send('Page.captureScreenshot',{format:'png',fromSurface:true,captureBeyondViewport:false,optimizeForSpeed:true});
      await writeFile(`${dir}/frame-${String(f).padStart(4,'0')}.png`,Buffer.from(shot.data,'base64'));
      if(f%60===0)console.log('FRAME',i,f);
    }
    if(smoke)continue;
    const encoder=spawnSync(process.env.FILM_FFMPEG,['-y','-hide_banner','-loglevel','warning','-xerror','-err_detect','explode','-framerate','60','-i',dir+'/frame-%04d.png','-frames:v','540','-an','-c:v','libx264','-preset','fast','-crf','17','-vf','scale=in_range=full:out_range=full:out_color_matrix=bt601','-pix_fmt','yuvj420p','-color_range','pc','-colorspace','bt470bg','-movflags','+faststart',base+`/media/scene-${i}.mp4`],{windowsHide:true,stdio:'inherit'});
    if(encoder.error)throw encoder.error;if(encoder.status)throw Error('Encoder failed: '+i);
  }
}finally{await browser.close();}
