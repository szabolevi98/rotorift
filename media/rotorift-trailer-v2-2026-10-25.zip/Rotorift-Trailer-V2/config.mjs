import {fileURLToPath} from 'node:url';
import {resolve} from 'node:path';
export const base=fileURLToPath(new URL('.',import.meta.url));
export const repoRoot=resolve(process.env.ROTORIFT_ROOT??'D:/xampp/htdocs/rotorift');
export const chrome=process.env.CHROME_PATH??'C:/Program Files/Google/Chrome/Application/chrome.exe';
export const url='http://127.0.0.1:3198/film';
export const chromeArgs=['--use-angle=d3d11','--enable-webgl','--ignore-gpu-blocklist','--disable-background-timer-throttling','--disable-renderer-backgrounding'];
