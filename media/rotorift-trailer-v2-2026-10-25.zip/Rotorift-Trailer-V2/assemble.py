from pathlib import Path
import argparse,subprocess,json,shutil
import imageio_ffmpeg

base=Path(__file__).parent
parser=argparse.ArgumentParser()
parser.add_argument('--fresh',action='store_true',help='use newly rendered scenes instead of approved reference media')
parser.add_argument('--copy-audio',action='store_true',help='keep the approved AAC payload for a video-only change')
args=parser.parse_args()
media=base/('media' if args.fresh else 'reference')
out=base/'generated';out.mkdir(exist_ok=True)
ff=imageio_ffmpeg.get_ffmpeg_exe()
def run(items):
    return subprocess.run([ff,'-y','-hide_banner','-loglevel','error',*map(str,items)],check=True,capture_output=True,text=True)
def concat_file(path,clips):
    path.write_text(''.join("file '"+clip.as_posix()+"'\n" for clip in clips),encoding='utf8')
if args.fresh:
    manifest=out/'flights.txt';concat_file(manifest,[media/f'scene-{i}.mp4' for i in range(5)])
    run(['-f','concat','-safe','0','-i',manifest,'-an','-frames:v','2700','-vf','scale=in_range=full:out_range=limited:in_color_matrix=bt601:out_color_matrix=bt709,format=yuv420p,setsar=1','-c:v','libx264','-preset','medium','-crf','18','-profile:v','high','-level:v','4.2','-color_range','tv','-colorspace','bt709','-color_primaries','bt709','-color_trc','bt709','-video_track_timescale','15360',media/'flights.mp4'])
    # The supplied WAV preserves the approved mix. Run score.py to resynthesize.
    score=base/'score.wav'
    if not score.exists():score=base/'reference/score.wav'
    if args.copy_audio:
        audio=base/'reference/audio.m4a'
        if not audio.exists():
            audio.parent.mkdir(exist_ok=True)
            approved=base/'approved'/json.loads((base/'manifest.json').read_text(encoding='utf8'))['approved_file']
            run(['-i',approved,'-map','0:a:0','-vn','-c:a','copy',audio])
        shutil.copy2(audio,media/'audio.m4a')
    else:run(['-i',score,'-vn','-af','loudnorm=I=-16:TP=-1:LRA=9','-c:a','aac','-b:a','192k','-ar','48000','-t','49',media/'audio.m4a'])
manifest=out/'concat.txt';concat_file(manifest,[media/'flights.mp4',media/'end.mp4'])
final=out/('Rotorift-Rerendered-1080p60.mp4' if args.fresh else 'Rotorift-Approved-Reassembled-1080p60.mp4')
approved=base/'approved'/json.loads((base/'manifest.json').read_text(encoding='utf8'))['approved_file']
if not args.fresh and approved.exists() and not (media/'flights.mp4').exists():
    shutil.copy2(approved,final)
else:
    run(['-f','concat','-safe','0','-i',manifest,'-i',media/'audio.m4a','-map','0:v:0','-map','1:a:0','-c','copy','-t','49','-movflags','+faststart','-metadata','title=Rotorift | Fly free','-metadata','comment=Scripted cinematic captured from the Rotorift game renderer. Original synthesized music and sound design.',final])
check=subprocess.run([ff,'-hide_banner','-xerror','-err_detect','explode','-i',str(final),'-map','0:v:0','-map','0:a:0','-f','null','-'],capture_output=True,text=True,check=True)
(out/'verification.txt').write_text(check.stderr,encoding='utf8')
assert 'frame= 2940' in check.stderr,check.stderr
if not args.fresh:
    expected=json.loads((base/'manifest.json').read_text(encoding='utf8'))['approved_stream_hashes']
    # Compare encoded payloads: this is stable across decoder threading and
    # proves the archive restores identical H.264 + AAC, without conversion.
    for kind,options in [('video',['-map','0:v:0','-an','-c:v','copy']),('audio',['-map','0:a:0','-vn','-c:a','copy'])]:
        actual=run(['-i',final,*options,'-f','hash','-hash','sha256','-']).stdout.strip().split('=')[-1]
        assert actual==expected[kind],(kind,actual,expected[kind])
        print(kind,'MATCHES APPROVED',actual,flush=True)
print('Verified: 49 seconds, 2940 frames, audio + video decode OK')
print(final)
