# Rotorift – megőrzött V2 trailer és YouTube-borító

Mentés: 2026-10-25. A kész videó 49 másodperces, 1920×1080, 60 fps, angol
feliratokkal. A repülős jelenet már a láthatóbb légcsavart és az alacsonyabb
kezdő követőkamerát használja. A többi jelenet, a hang és a javított zárókép
az elfogadott változatból maradt meg.

## Kész fájlok

- `approved/Rotorift-Trailer-English-Final-v2-1080p60.mp4`: a teljes kész videó.
- `cover/Rotorift-OG-YouTube-recreated-master.png`: a változatlan PNG mester.
- `cover/Rotorift-OG-YouTube-recreated-1280x720.jpg`: a kész YouTube-bélyegkép.
- A `cover` mappában az eredeti OG-referencia, a prompt és a készítési jegyzet is megtalálható.
- `manifest.json`: fájlméretek, SHA-256 értékek és a használt verziók.

A kész videót és képeket a ZIP kicsomagolása után közvetlenül használhatod.

## Ellenőrzött gyors visszaállítás

A kicsomagolt mappában:

```powershell
python -m pip install imageio-ffmpeg==0.6.0
python assemble.py
```

Ez az archívumban lévő kész MP4-t másolja a `generated` mappába, újratömörítés
nélkül. Végigdekódolja mind a 2940 képkockát és a hangot, majd ellenőrzi az
elfogadott H.264 és AAC adatfolyamok lenyomatát. `MATCHES APPROVED` és
`Verified: 49 seconds, 2940 frames, audio + video decode OK` eredmény várható.

## Új render a játékból

A renderkód, a zene forrása, az eredeti WAV és a rögzített függőségek is itt vannak.
A `REPRODUCING.md` **2. Teljes újrarenderelés a játékból** része tartalmazza a
pontos parancsokat és a játékforrás szükséges commitját. A szokásos sorrend:

1. Játékforrás külön klónja a rögzített verzióval, majd annak `npm ci` telepítése.
2. Ebben a mappában `npm ci` és `python -m pip install -r requirements.txt`.
3. `ROTORIFT_ROOT`, `CHROME_PATH` és `FILM_FFMPEG` beállítása, `node server.mjs`.
4. Másik terminálban `node render.mjs`, `node render-endcard.mjs`,
   `python score.py`, végül `python assemble.py --fresh`.

A különálló korábbi köztes MP4-sávokat nem duplázzuk meg ebben a ZIP-ben:
a gyors visszaállítás a kész videót használja, a `--fresh` folyamat pedig
újra előállítja a köztes sávokat a mellékelt kódból. A `--fresh --copy-audio`
opció az archívumban lévő kész videóból veszi át az eredeti AAC-hangsávot.
