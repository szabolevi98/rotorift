import {WIDTH as W,HEIGHT as H,FPS,DURATION,chapters,shotAt} from './timeline.mjs';
await import('./scene.js');
const canvas=document.querySelector('#output'),ctx=canvas.getContext('2d',{alpha:false}),icon=window.shortIcon;
const clamp=x=>Math.max(0,Math.min(1,x));
const smooth=x=>(x=clamp(x))*x*(3-2*x);
function text(value,x,y,size,colour='#fffaf0',weight=700){ctx.fillStyle=colour;ctx.font=`${weight} ${size}px Arial,sans-serif`;ctx.fillText(value,x,y);}
function spaced(value,x,y,size,gap,colour='#fffaf0',weight=700){ctx.fillStyle=colour;ctx.font=`${weight} ${size}px Arial,sans-serif`;for(const c of value){ctx.fillText(c,x,y);x+=ctx.measureText(c).width+gap;}}
function brand(){
 ctx.drawImage(icon,72,136,52,52);text('ROTORIFT',141,178,46,'#faf8f0',800);
 const width=ctx.measureText('ROTORIFT').width;text('.',141+width,178,46,'#ff693f',800);
}
window.drawShortOverlays=()=>{
 const shot=window.shortContext;if(!shot||shot.outro)return;
 const chapter=chapters[shot.chapter];
 let g=ctx.createLinearGradient(0,0,0,520);g.addColorStop(0,'#081015bb');g.addColorStop(1,'#08101500');ctx.fillStyle=g;ctx.fillRect(0,0,W,520);
 g=ctx.createLinearGradient(0,1170,0,H);g.addColorStop(0,'#08101500');g.addColorStop(.65,'#081015b5');g.addColorStop(1,'#081015e5');ctx.fillStyle=g;ctx.fillRect(0,1170,W,H-1170);
 brand();spaced('FPV. ON THE GO.',74,229,23,3,'#e0e6e0',500);
 for(let i=0;i<5;i++){ctx.fillStyle=i===shot.chapter?'#ff693f':'#ffffff55';ctx.fillRect(74+i*140,265,112,5);}
 const alpha=smooth(shot.local/.1)*(1-smooth((shot.local-1.05)/.35));
 ctx.save();ctx.globalAlpha=alpha;
 const font=shot.chapter===3?64:86;
 chapter.headline.forEach((line,i)=>text(line,72,408+i*98,font,'#fffaf0',800));ctx.restore();
 ctx.fillStyle='#ff693f';ctx.fillRect(74,1378,5,111);
 spaced(`${String(shot.chapter+1).padStart(2,'0')} / ${chapter.map}`,99,1414,31,2,'#f6f4e9',700);
 text(chapter.aircraft,99,1465,36,'#dce5df',600);
 text('fpv.levente.net',74,1550,32,'#f6f4e9',500);
 if(shot.chapter>0&&shot.local<.08){ctx.fillStyle=`rgba(255,243,222,${.15*(1-shot.local/.08)})`;ctx.fillRect(0,0,W,H);}
};
let endBackground;
function background(){
 if(endBackground)return endBackground;
 const c=document.createElement('canvas');c.width=W;c.height=H;const cc=c.getContext('2d'),pixels=cc.createImageData(W,H);
 let seed=0x72696674;const random=()=>{seed^=seed<<13;seed^=seed>>>17;seed^=seed<<5;return (seed>>>0)/4294967296;};
 for(let y=0;y<H;y++)for(let x=0;x<W;x++){
  const amount=clamp((Math.hypot(x-W/2,y-850)-65)/1250),noise=(random()+random()-1)*1.5,at=(y*W+x)*4;
  pixels.data[at]=Math.round(30-19*amount+noise);pixels.data[at+1]=Math.round(43-27*amount+noise);pixels.data[at+2]=Math.round(48-28*amount+noise);pixels.data[at+3]=255;
 }
 cc.putImageData(pixels,0,0);endBackground=c;return c;
}
function endCard(t){
 ctx.drawImage(background(),0,0);ctx.strokeStyle='#ffffff07';ctx.lineWidth=1;
 for(let i=-1600;i<1500;i+=100){ctx.beginPath();ctx.moveTo(i,0);ctx.lineTo(i+1450,H);ctx.stroke();}
 ctx.save();ctx.globalAlpha=smooth(t/.15);ctx.drawImage(icon,468,424,144,144);
 ctx.font='800 108px Arial,sans-serif';const width=ctx.measureText('ROTORIFT').width,dot=ctx.measureText('.').width,x=(W-width-dot)/2;
 text('ROTORIFT',x,765,108,'#fffaf0',800);text('.',x+width,765,108,'#ff693f',800);
 ctx.textAlign='center';text('FPV. ON THE GO.',W/2,853,32,'#dce5df',500);
 ctx.fillStyle='#ff693f';ctx.fillRect(410,927,260,5);
 text('FLY FREE.',W/2,1064,66,'#fffaf0',800);
 text('Play in your browser.',W/2,1160,40,'#d5dfd9',500);
 text('Desktop + mobile.',W/2,1220,36,'#becbc7',400);
 text('fpv.levente.net',W/2,1370,60,'#ff805a',700);
 text('More drones. More maps.',W/2,1460,29,'#aebdb7',400);
 ctx.textAlign='left';ctx.restore();
}
window.renderShort=async time=>{
 const shot=shotAt(time);window.shortContext=shot;
 if(shot.outro){endCard(shot.time);return;}
 await window.loadChapter(shot.chapter);await window.renderFilm(shot.chapter*9+shot.source);
};
window.shortInfo={width:W,height:H,fps:FPS,duration:DURATION,frames:DURATION*FPS,chapters};
window.shortReady=true;
