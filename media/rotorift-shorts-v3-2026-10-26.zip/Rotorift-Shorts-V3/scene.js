import * as THREE from 'three';
import {buildPark} from '/game/park.js';
import {buildCircuit} from '/game/circuit.js';
import {buildGym} from '/game/gym.js';
import {buildCity} from '/game/city.js';
import {buildHarbor} from '/game/harbor.js';
import {CircuitTraffic} from '/game/circuit-traffic.js';
import {circuitCarState,circuitPoint} from '/shared/world/circuit-layout.js';
import {createMapAtmosphere} from '/game/map-atmosphere.js';
import {createWorldBackdrop} from '/game/world-backdrop.js';
import {ParkShadows} from '/game/park-shadows.js';
import {loadModel} from '/game/models.js';
import {createAircraftVisual} from '/game/aircraft-visual.js';
import {configureDroneRenderer} from '/shared/visual/drone-rendering.js';
import {applyDroneColor} from '/shared/visual/drone-colors.js';
import {validAirplaneAnimation} from '/shared/aircraft/animation.js';
import {animateFixedWingModel} from '/shared/visual/airplane-model-utils.js';
import {mapViewDistance} from '/shared/world/view-distance.js';
import {FilmPropellerExposure} from '/propeller-exposure.js';
import {pitchForMotion,sampleMotion} from '/flight-attitude.mjs';

const W=1080,H=1920;
const canvas=document.createElement('canvas');
const renderer=new THREE.WebGLRenderer({canvas,antialias:true,logarithmicDepthBuffer:true,preserveDrawingBuffer:true});
renderer.setPixelRatio(1);renderer.setSize(W,H);configureDroneRenderer(THREE,renderer);
const out=document.querySelector('#output');out.width=W;out.height=H;
const ctx=out.getContext('2d',{alpha:false});
const camera=new THREE.PerspectiveCamera(80,W/H,.012,2200);
const catalog=await (await fetch('/api/catalog')).json();
const all=[...catalog.drones,...catalog.airplanes];
const V=a=>new THREE.Vector3(...a);
const clamp=t=>Math.max(0,Math.min(1,t));
const smooth=t=>(t=clamp(t))*t*(3-2*t);
const lerp=THREE.MathUtils.lerp;
let scene,environment,atmosphere,backdrop,shadows,traffic,model,visual,propellerExposure,config,active=-1;
const chapters=[
  {map:'apex',air:'rift-x5',title:'CHASE THE THRILL.',name:'APEX CIRCUIT',sub:'RIFT X5  /  5″ FREESTYLE',duration:9},
  {map:'liget',air:'rift-c3',title:'FIND YOUR LINE.',name:'GROVE',sub:'RIFT C3  /  3″ CINEWHOOP',duration:9},
  {map:'skyline',air:'rift-t15',title:'TAKE TO THE SKIES.',name:'SKYLINE',sub:'RIFT AERO 150  /  1500 MM TRAINER',duration:9},
  {map:'gym',air:'rift-65',title:'EVERY SPACE. YOUR PLAYGROUND.',name:'GYMNASIUM',sub:'RIFT 65  /  65 MM TINYWHOOP',duration:9},
  {map:'harbor',air:'rift-r5',title:'BUILT FOR SPEED.',name:'HARBOR',sub:'RIFT R5  /  5″ RACING',duration:9},
];
const curve=points=>new THREE.CatmullRomCurve3(points.map(V),false,'catmullrom',.28);
const paths={
  liget:curve([[1,3.1,53],[.5,2.4,35],[0,2.1,18],[0,1.8,5],[.1,1.9,-10],[1.5,2.4,-24],[7,5,-42],[13,12,-59]]),
  skyline:curve([[0,61,155],[0,51,110],[0,41,65],[0,35,22],[0,35,-25],[4,38,-49],[30,43,-60],[55,48,-67],[60,55,-95]]),
  gym:curve([[-5,1,16],[-5,.9,11],[-5,.85,7],[-5,.85,3],[-4.5,1.8,-.7],[-2.5,2.2,-4],[1.5,.9,-4],[3.8,.9,-4.4],[5.2,1,-6],[5.8,1.2,-8.5],[7,2,-11],[7.8,3,-14]]),
  harbor:curve([[-85,4.4,263],[-85,4.4,245],[-85,4.4,226],[-85,5,218],[-72,9,205],[-35,15,188],[10,18,171],[30,18,156],[30,18,132],[35,21,110],[70,24,85],[112,27,47],[140,28,18],[165,30,-25]])
};
const icon=new Image();icon.src='/assets/icon.svg';await icon.decode();
window.loadChapter=async(index)=>{
  if(index===active)return;
  if(shadows)shadows.dispose();propellerExposure?.dispose();visual?.dispose();traffic?.dispose();backdrop?.dispose();environment?.dispose();atmosphere?.dispose();
  if(model){scene?.remove(model);model.traverse(o=>{for(const m of Array.isArray(o.material)?o.material:[o.material])m?.dispose();});}
  renderer.renderLists.dispose();scene=new THREE.Scene();
  const chapter=chapters[index],base=catalog.maps.find(m=>m.id===chapter.map);
  const map={...base,gates:[],guide:null};
  const builders={apex:buildCircuit,liget:buildPark,skyline:buildCity,gym:buildGym,harbor:buildHarbor};
  environment=builders[chapter.map](scene,null,null,map);
  backdrop=createWorldBackdrop(scene,map,environment.root);
  atmosphere=createMapAtmosphere(renderer,scene,map.kind);
  config=all.find(c=>c.id===chapter.air);
  model=await loadModel(config,{isolateMaterials:true});applyDroneColor(model,'coral');scene.add(model);
  visual=createAircraftVisual(model,config,{remote:true});
  visual.exposure?.dispose();
  propellerExposure=new FilmPropellerExposure(THREE,renderer,model,config);
  traffic=chapter.map==='apex'?new CircuitTraffic(scene,null,null):null;
  // Swap only the two liveries. The traffic clock, seed, cars and camera path
  // retain the approved shot's exact positions and timing.
  if(traffic){
    for(const mesh of traffic.batches){
      if(!mesh.instanceColor)continue;
      const followed=new THREE.Color(),leading=new THREE.Color();
      mesh.getColorAt(0,followed);mesh.getColorAt(1,leading);
      mesh.setColorAt(0,leading);mesh.setColorAt(1,followed);
      mesh.instanceColor.needsUpdate=true;
    }
  }
  camera.far=mapViewDistance(map);
  camera.fov=80;camera.updateProjectionMatrix();
  shadows=chapter.map==='gym'?null:new ParkShadows(scene,camera,atmosphere.profile);
  active=index;
  window.filmDebug={scene,camera,renderer,environment,backdrop,shadows,model,propellerExposure};
  await window.renderFilm(index*9+.1);
  if(renderer.compileAsync)await renderer.compileAsync(scene,camera);
  return {map:map.id,aircraft:config.id,meshes:renderer.info.render.calls};
};
function rawPoseAt(index,t){
  const chapter=chapters[index];
  if(index===0){
    const car=circuitCarState(2+t,0,0),p=circuitPoint(car.distance-7.2+.7*Math.sin(t*.65),-4.5+1.25*Math.sin(t*.5));
    const p2=circuitPoint(car.distance-5.5,-4.5+1.25*Math.sin(t*.5));
    return {p:new THREE.Vector3(p.x,2.7+.5*Math.sin(t*.65),p.z),forward:new THREE.Vector3(p2.x-p.x,-.025,p2.z-p.z).normalize(),bank:THREE.MathUtils.clamp(-car.curvature*32,-.3,.3),car};
  }
  const c=paths[chapter.map],u=clamp(t/9),p=c.getPointAt(u),tangent=c.getTangentAt(Math.min(.99999,u));
  const a=c.getTangentAt(clamp(u-.015)),b=c.getTangentAt(clamp(u+.015));
  return {p,forward:tangent,bank:THREE.MathUtils.clamp(a.clone().cross(b).y*(index===2?-3:-1.1),-.36,.36)};
}
// Build the flight at 240 Hz first. A symmetric Gaussian shutter removes the
// discontinuous turn accelerations at spline knots and the road sample joins.
// Positions and heading are filtered separately, so increasing the output FPS
// does not merely repeat the original angular steps.
const MOTION_HZ=240,COUNT=9*MOTION_HZ+1;
function gaussian(values,sigmaSeconds,extrapolate=false){
  const sigma=sigmaSeconds*MOTION_HZ,radius=Math.ceil(sigma*3.5);
  const weights=Array.from({length:radius*2+1},(_,j)=>Math.exp(-.5*((j-radius)/sigma)**2));
  const total=weights.reduce((a,b)=>a+b,0);
  function sample(j){
    if(j<0)return extrapolate?values[0].clone().addScaledVector(values[1].clone().sub(values[0]),j):values[0];
    if(j>=values.length)return extrapolate?values.at(-1).clone().addScaledVector(values.at(-1).clone().sub(values.at(-2)),j-values.length+1):values.at(-1);
    return values[j];
  }
  return values.map((_,i)=>{
    const result=new THREE.Vector3();
    for(let j=-radius;j<=radius;j++)result.addScaledVector(sample(i+j),weights[j+radius]/total);
    return result;
  });
}
const motionTables=chapters.map((chapter,index)=>{
  const raw=Array.from({length:COUNT},(_,i)=>rawPoseAt(index,i/MOTION_HZ));
  const positions=gaussian(raw.map(s=>s.p),index===3?.19:.22,true);
  const directions=gaussian(positions.map((_,i)=>positions[Math.min(COUNT-1,i+12)].clone().sub(positions[Math.max(0,i-12)]).normalize()),index===3?.3:.20).map(v=>v.normalize());
  const banks=gaussian(directions.map((f,i)=>{
    const a=directions[Math.max(0,i-18)],b=directions[Math.min(COUNT-1,i+18)];
    const yawRate=Math.atan2(a.clone().cross(b).y,a.dot(b)) / (Math.min(COUNT-1,i+18)-Math.max(0,i-18))*MOTION_HZ;
    const speed=positions[Math.min(COUNT-1,i+1)].distanceTo(positions[Math.max(0,i-1)])*MOTION_HZ/(Math.min(COUNT-1,i+1)-Math.max(0,i-1));
    const bank=-.36*Math.tanh(Math.atan(speed*yawRate/9.81)/.6);
    return new THREE.Vector3(bank,0,0);
  }),.22);
  const aircraft=all.find(c=>c.id===chapter.air);
  const motion=sampleMotion(positions.map(p=>p.toArray()),MOTION_HZ);
  const pitches=index===2?positions.map(()=>new THREE.Vector3()):gaussian(positions.map((_,i)=>
    new THREE.Vector3(pitchForMotion(motion.velocity[i],motion.acceleration[i],directions[i].toArray(),aircraft),0,0)),.25);
  return positions.map((p,i)=>({p,forward:directions[i],bank:banks[i].x,pitch:pitches[i].x,
    speed:Math.hypot(...motion.velocity[i]),car:raw[i].car}));
});
function poseAt(index,t){
  const table=motionTables[index],u=clamp(t/9)*(COUNT-1),i=Math.min(COUNT-2,Math.floor(u)),a=table[i],b=table[i+1],f=u-i;
  return {p:a.p.clone().lerp(b.p,f),forward:a.forward.clone().lerp(b.forward,f).normalize(),bank:lerp(a.bank,b.bank,f),pitch:lerp(a.pitch,b.pitch,f),speed:lerp(a.speed,b.speed,f),car:rawPoseAt(index,t).car};
}
function poseQuaternion(forward,bank){
  return new THREE.Quaternion().setFromRotationMatrix(new THREE.Matrix4().lookAt(new THREE.Vector3(),forward,new THREE.Vector3(0,1,0)))
    .multiply(new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0,0,1),bank));
}
function cameraAt(index,t){
  const {p,forward,bank,car}=poseAt(index,t);
  const right=new THREE.Vector3().crossVectors(forward,new THREE.Vector3(0,1,0)).normalize();
  const blend=smooth((t-2.35)/1.25);
  const behind=[1.15,.85,2.8,.36,1.15][index],height=[.45,.26,.2,.13,.45][index],side=[.35,.2,1.9,.1,.35][index];
  const chasePosition=p.clone().addScaledVector(forward,-behind).addScaledVector(right,side);chasePosition.y+=height;
  const target=p.clone().addScaledVector(forward,index===2?.35:.55);
  const chaseQ=new THREE.Quaternion().setFromRotationMatrix(new THREE.Matrix4().lookAt(chasePosition,target,new THREE.Vector3(0,1,0)));
  let fpvQ=poseQuaternion(forward,bank);
  if(index===0){
    const towardCar=new THREE.Vector3(car.x,1,car.z).sub(p).normalize();
    fpvQ=poseQuaternion(towardCar,bank*.55);
  }
  const fpvPosition=p.clone();
  if(index===2)fpvPosition.addScaledVector(forward,.56).add(new THREE.Vector3(0,.10,0));
  return {position:chasePosition.lerp(fpvPosition,blend),quaternion:chaseQ.slerp(fpvQ,blend),fov:lerp(64,90,blend),blend};
}
window.filmDiagnostics=()=>chapters.map((_,index)=>{
  let maxFrameTurn=0,maxFrameAcceleration=0,previousRate=0,maxTime=0,detail;
  for(let frame=1;frame<540;frame++){
    const a=cameraAt(index,(frame-1)/60),b=cameraAt(index,frame/60);
    const degrees=a.quaternion.angleTo(b.quaternion)*180/Math.PI;
    if(degrees>maxFrameTurn){maxFrameTurn=degrees;maxTime=frame/60;detail={p:poseAt(index,maxTime).p.toArray(),car:poseAt(index,maxTime).car,blend:b.blend};}
    if(frame>1)maxFrameAcceleration=Math.max(maxFrameAcceleration,Math.abs(degrees-previousRate));
    previousRate=degrees;
  }
  return {chapter:index,aircraft:chapters[index].air,maxFrameTurn,maxFrameAcceleration,maxTime,detail};
});
window.filmPathSamples=index=>Array.from({length:541},(_,i)=>({p:poseAt(index,i/60).p.toArray(),camera:cameraAt(index,i/60).position.toArray()}));
function spaced(text,x,y,size,spacing,color='#f7f5ef',weight=600){
  ctx.fillStyle=color;ctx.font=`${weight} ${size}px "Arial",sans-serif`;
  for(const ch of text){ctx.fillText(ch,x,y);x+=ctx.measureText(ch).width+spacing;}
}
function text(text,x,y,size,color='#f7f5ef',weight=700){ctx.font=`${weight} ${size}px "Arial",sans-serif`;ctx.fillStyle=color;ctx.fillText(text,x,y);}
function brand(x,y,scale=1){
  ctx.drawImage(icon,x,y,42*scale,42*scale);
  text('ROTORIFT',x+56*scale,y+33*scale,34*scale,'#faf8f0',800);
  text('.',x+240*scale,y+33*scale,34*scale,'#ff693f',800);
}
function overlays(index,t,global){window.drawShortOverlays?.();}
let endBackground;
function makeEndBackground(){
  const background=document.createElement('canvas');background.width=W;background.height=H;
  const backgroundContext=background.getContext('2d'),pixels=backgroundContext.createImageData(W,H);
  // Calculate the shallow gradient before 8-bit quantization. Static, subtle
  // triangular dither breaks up contours without changing the artwork or text.
  let seed=0x72696674;
  const random=()=>{seed^=seed<<13;seed^=seed>>>17;seed^=seed<<5;return (seed>>>0)/4294967296;};
  for(let y=0;y<H;y++)for(let x=0;x<W;x++){
    const amount=Math.min(1,Math.max(0,(Math.hypot(x-960,y-500)-60)/860));
    const noise=(random()+random()-1)*1.5,at=(y*W+x)*4;
    pixels.data[at]=Math.round(30-19*amount+noise);
    pixels.data[at+1]=Math.round(43-27*amount+noise);
    pixels.data[at+2]=Math.round(48-28*amount+noise);
    pixels.data[at+3]=255;
  }
  backgroundContext.putImageData(pixels,0,0);return background;
}
function endCard(t){
  endBackground??=makeEndBackground();ctx.drawImage(endBackground,0,0);
  ctx.strokeStyle='#ffffff07';ctx.lineWidth=1;
  for(let i=-900;i<2000;i+=100){ctx.beginPath();ctx.moveTo(i,0);ctx.lineTo(i+900,H);ctx.stroke();}
  const a=smooth(t/.35);ctx.save();ctx.globalAlpha=a;
  ctx.drawImage(icon,894,210,132,132);
  ctx.font='800 132px Arial,sans-serif';
  const wordWidth=ctx.measureText('ROTORIFT').width,dotWidth=ctx.measureText('.').width;
  const wordX=(W-wordWidth-dotWidth)/2;
  text('ROTORIFT',wordX,476,132,'#fcf8ed',800);text('.',wordX+wordWidth,476,132,'#ff693f',800);
  ctx.textAlign='center';
  text('FPV. ON THE GO.',960,555,32,'#dce5df',500);
  ctx.fillStyle='#ff693f';ctx.fillRect(867,609,186,4);
  text('FLY FREE.',960,705,47,'#fcf8ed',700);
  text('In your browser. On desktop and mobile.',960,762,28,'#becbc7',400);
  text('fpv.levente.net',960,872,42,'#ff805a',600);
  ctx.textAlign='left';ctx.restore();
  if(t>3.65){ctx.fillStyle=`rgba(8,13,16,${smooth((t-3.65)/.35)})`;ctx.fillRect(0,0,W,H);}
}
window.renderFilm=async global=>{
  if(global>=chapters.length*9){endCard(global-chapters.length*9);return;}
  const index=Math.min(chapters.length-1,Math.floor(global/9)),t=global-index*9;
  if(active!==index)throw Error('Chapter must be loaded before rendering');
  const {p,forward,bank,pitch,speed}=poseAt(index,t);
  const bodyForward=index===2?forward:new THREE.Vector3(forward.x,0,forward.z).normalize();
  const q=poseQuaternion(bodyForward,bank);
  model.position.copy(p);model.quaternion.copy(q);
  if(index!==2)model.quaternion.multiply(new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(1,0,0),-pitch));
  window.filmAttitude={pitchDegrees:pitch*180/Math.PI,speedMps:speed,bankDegrees:bank*180/Math.PI};
  const state=config.kind==='fixedWing'?{animation:{kind:'fixedWing',engine:.68,surfaces:{roll:bank*.4,pitch:0,yaw:0},propeller:[0,0]}}:{rotorSpeeds:[.55,.56,.55,.57],propellers:[[0,0,0],[0,0,0],[0,0,0],[0,0,0]]};
  if(config.kind==='fixedWing'&&!validAirplaneAnimation(state.animation))throw Error('Invalid aircraft animation');
  visual.updateRemote(1/60,{...state,connected:true,resetId:0});
  if(config.kind==='fixedWing'){
    animateFixedWingModel(model,state.animation.surfaces,0);
  }
  propellerExposure.update(t,config.kind==='fixedWing'?[state.animation.engine]:state.rotorSpeeds);
  window.filmAnimationState={aircraft:config.id,engine:visual.motorSpeeds[0],phases:[]};
  window.filmRotorExposure=propellerExposure.diagnostics();
  model.traverse(o=>{if(o.userData.propeller)window.filmAnimationState.phases.push(config.kind==='fixedWing'?o.rotation.z:o.rotation.y);});
  const view=cameraAt(index,t);
  const modelOpacity=1-smooth((view.blend-.12)/.46);
  camera.position.copy(view.position);camera.quaternion.copy(view.quaternion);
  camera.fov=view.fov+8;camera.updateProjectionMatrix();
  const now=performance.now;performance.now=()=>1000+global*1000;
  try{
    environment.update(p.toArray(),forward.clone().multiplyScalar(index===2?20:10).toArray());
    traffic?.render(2+t,0);
    camera.updateMatrixWorld();
    const drawAircraft=visible=>{
      model.visible=visible;shadows?.update({dynamic:true});
      renderer.render(scene,camera);
    };
    // Composite two fully depth-tested images rather than making individual
    // aircraft materials transparent. Parts keep their proper occlusion and
    // the entire assembled aircraft dissolves uniformly into the clean view.
    drawAircraft(modelOpacity>.001);ctx.drawImage(canvas,0,0,W,H);
    if(modelOpacity>.001&&modelOpacity<.999){
      drawAircraft(false);
      ctx.save();ctx.globalAlpha=1-modelOpacity;ctx.drawImage(canvas,0,0,W,H);ctx.restore();
    }
  }finally{performance.now=now;}
  overlays(index,t,global);
};
window.filmAppearanceState=()=>{
  const colors=[];
  if(traffic)for(const mesh of traffic.batches)if(mesh.instanceColor){
    for(let i=0;i<8;i++){const c=new THREE.Color();mesh.getColorAt(i,c);colors.push(c.getHexString());}
  }
  let alteredMaterials=0;model?.traverse(o=>{for(const m of Array.isArray(o.material)?o.material:[o.material])if(m?.opacity<.999&&!m.transparent)alteredMaterials++;});
  return {colors,alteredMaterials};
};
window.renderGymDetail=async()=>{
  await window.loadChapter(3);model.visible=false;
  camera.position.set(10,2.7,1.3);camera.up.set(0,1,0);camera.lookAt(5,1.12,-4);
  camera.fov=43;camera.updateProjectionMatrix();camera.updateMatrixWorld();
  environment.update([5,1,-4],[0,0,0]);renderer.render(scene,camera);ctx.drawImage(canvas,0,0,W,H);
};
window.filmInfo={chapters,W,H,duration:chapters.length*9+4,fps:60,renderer:renderer.getContext().getParameter(renderer.getContext().RENDERER)};
window.filmReady=true;

window.shortIcon=icon;

window.filmAttitudeSamples=index=>motionTables[index].map(s=>({pitchDegrees:s.pitch*180/Math.PI,speedMps:s.speed}));
