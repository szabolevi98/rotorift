"""Build the current film archive and verify every member."""
from pathlib import Path
import argparse,hashlib,json,zipfile
from finalize import NAME,verify
BASE=Path(__file__).resolve().parent
LONG=(BASE/'trailer.js').exists()
ROOT='Rotorift-Trailer-V4/' if LONG else 'Rotorift-Shorts-V3/'
SOURCES=['README.md','config.mjs','server.mjs','propeller-exposure.js','flight-attitude.mjs',
 'render.mjs','finalize.py','pack.py','score.py','score.wav','package.json','package-lock.json',
 'requirements.txt','test-flight-attitude.mjs','attitude-samples.json','verification-summary.json','final-contact.jpg']
SOURCES+=['trailer.html','trailer.js','render-endcard.mjs','test-propeller-exposure.mjs','reference/audio.m4a','reference/end.mp4'] if LONG else ['shorts.html','shorts.js','scene.js','timeline.mjs','test-timeline.mjs','preview-checks.json','reference/audio.m4a']
def sha(data):return hashlib.sha256(data).hexdigest()
def main():
 parser=argparse.ArgumentParser()
 parser.add_argument('--master',type=Path,default=BASE/'approved'/NAME)
 parser.add_argument('--destination',type=Path,default=BASE/('rotorift-trailer-v4-2026-10-26.zip' if LONG else 'rotorift-shorts-v3-2026-10-26.zip'))
 args=parser.parse_args();approved=verify(args.master)
 payload={name:(BASE/name).read_bytes() for name in SOURCES}
 payload['approved/'+NAME]=args.master.read_bytes()
 payload['approved/'+Path(NAME).with_suffix('.verification.json').name]=json.dumps(approved,indent=2).encode()
 manifest={'created':'2026-10-26','game_commit':'60915f6120ab985c5199220bcd13c6b77fefc7a7',
  'game_repo':'https://github.com/szabolevi98/rotorift.git','approved_file':'approved/'+NAME,'approved':approved,
  'files':{name:{'bytes':len(data),'sha256':sha(data)} for name,data in payload.items()}}
 payload['manifest.json']=json.dumps(manifest,indent=2).encode()
 args.destination.parent.mkdir(parents=True,exist_ok=True)
 with zipfile.ZipFile(args.destination,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
  for name,data in payload.items():archive.writestr(ROOT+name,data)
 with zipfile.ZipFile(args.destination) as archive:
  assert archive.testzip() is None
  for name,expected in manifest['files'].items():
   data=archive.read(ROOT+name);assert len(data)==expected['bytes'] and sha(data)==expected['sha256'],name
 result={'archive':str(args.destination),'bytes':args.destination.stat().st_size,'sha256':sha(args.destination.read_bytes()),'members':len(payload),'verification':'All ZIP CRC and SHA-256 checks passed'}
 args.destination.with_suffix('.verification.json').write_text(json.dumps(result,indent=2),encoding='utf8')
 print(json.dumps(result,indent=2))
if __name__=='__main__':main()
