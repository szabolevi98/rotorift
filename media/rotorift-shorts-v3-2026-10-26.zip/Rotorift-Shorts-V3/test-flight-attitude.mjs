import {test} from 'node:test';
import assert from 'node:assert/strict';
import {pitchForMotion,sampleMotion,PITCH_LIMITS} from './flight-attitude.mjs';
const config={massKg:.68,linearDrag:.014,quadraticDrag:.0135},forward=[0,0,-1];
const pitch=(speed,acceleration=0)=>pitchForMotion([0,0,-speed],[0,0,-acceleration],forward,config);
test('hover is level; fast forward flight leans farther than slow flight',()=>{
 assert.equal(pitch(0),0);
 assert.ok(pitch(20)>pitch(5));
 assert.ok(pitch(20)>35*Math.PI/180);
 assert.ok(pitch(5)<8*Math.PI/180);
});
test('acceleration adds forward tilt; sufficiently strong braking tilts backward',()=>{
 assert.ok(pitch(5,4)>pitch(5));
 assert.ok(pitch(5,-4)<0);
 const same=pitchForMotion([5,0,0],[4,0,0],[1,0,0],config);
 assert.ok(Math.abs(same-pitch(5,4))<1e-12);
 assert.ok(pitch(1000)<PITCH_LIMITS.max && pitch(1000)>50*Math.PI/180);
 assert.ok(pitch(0,-1000)>PITCH_LIMITS.min && pitch(0,-1000)<-30*Math.PI/180);
});
test('path derivatives preserve constant speed including first and last frame',()=>{
 const positions=Array.from({length:241},(_,i)=>[0,0,-20*i/240]);
 const {velocity,acceleration}=sampleMotion(positions,240);
 for(let i=0;i<positions.length;i++){
  assert.ok(Math.abs(velocity[i][2]+20)<1e-10);
  assert.ok(Math.abs(acceleration[i][2])<1e-8);
 }
});

test('Rift 65 film shot has stronger visible forward lean without tilting hover or braking',()=>{
 const whoop={id:'rift-65',massKg:.026,linearDrag:.001,quadraticDrag:.0025};
 const tilt=pitchForMotion([0,0,-4.2],[0,0,0],forward,whoop)*180/Math.PI;
 assert.ok(tilt>21&&tilt<24);
 assert.equal(pitchForMotion([0,0,0],[0,0,0],forward,whoop),0);
 assert.ok(pitchForMotion([0,0,-4.2],[0,0,4],forward,whoop)<0);
});
