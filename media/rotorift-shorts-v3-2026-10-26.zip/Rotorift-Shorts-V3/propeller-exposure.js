// Offline film exposure only. The live game's renderer and physics are untouched.
export const FILM_SHUTTER_SECONDS=1/120;
export const PLANE_SHUTTER_SECONDS=1/2000;
export const PLANE_SHUTTER_SAMPLES=32;
export const filmShutterSeconds=config=>config.kind==='fixedWing'?PLANE_SHUTTER_SECONDS:FILM_SHUTTER_SECONDS;
export function filmRotorMotion(config,time,fractions){
  const radius=config.propDiameterM/2;
  const tipSpeed=config.simulation?.propeller?.maxTipSpeedMps??150;
  return config.motors.map((motor,i)=>{
    const fraction=Math.max(0,Math.min(1,fractions[i]??0));
    const angularSpeed=tipSpeed/radius*fraction*motor.direction;
    return {fraction,angularSpeed,phase:time*angularSpeed,rpm:Math.abs(angularSpeed)*60/(2*Math.PI),
      exposureTurns:Math.abs(angularSpeed)*filmShutterSeconds(config)/(2*Math.PI)};
  });
}

// Integrate the actual blade silhouette over a complete revolution, retaining
// its radial shape, material colour and transparency. At this film's operating
// speeds every quad rotor makes at least one turn during a 1/120 s shutter. The
// rotational mean avoids falsely frozen/reversing blades at 60 fps. Opaque hubs,
// motor bells, guards and the airframe keep their normal geometry and depth.
// The airplane instead gets a shorter, 32-sample 1/2000 s exposure, retaining
// the visible sweep of both real blades rather than losing them in a full disc.
export class FilmPropellerExposure {
  constructor(THREE,renderer,model,config){
    this.THREE=THREE;this.config=config;this.entries=[];
    model.updateMatrixWorld(true);
    const props=[];model.traverse(o=>{if(o.userData.propeller)props.push(o);});
    const radius=config.propDiameterM/2,axis=config.kind==='fixedWing'?'z':'y';
    for(const prop of props){
      const blades=prop.children.filter(o=>o.userData.bladeIndex!==undefined);
      if(blades.length!==(axis==='z'?2:3))throw Error('Missing film rotor blade geometry: '+prop.name);
      const profile=this.profile(THREE,renderer,prop,blades,radius,axis);
      const geometry=new THREE.RingGeometry(0,radius*1.025,128,48);
      const positions=geometry.attributes.position,uv=geometry.attributes.uv;
      for(let i=0;i<positions.count;i++)uv.setXY(i,Math.hypot(positions.getX(i),positions.getY(i))/(radius*1.025),.5);
      if(axis==='y')geometry.rotateX(-Math.PI/2);
      const material=new THREE.MeshStandardMaterial({color:0xffffff,map:profile.texture,roughness:.6,metalness:0,
        transparent:true,depthWrite:false,side:THREE.DoubleSide});
      const disc=new THREE.Mesh(geometry,material);disc.name='Film_rotor_exposure_'+prop.userData.motorIndex;
      disc.position[axis]=profile.height;disc.castShadow=false;disc.receiveShadow=true;
      prop.add(disc);
      const saved=[];
      for(const blade of blades){
        saved.push({object:blade,visible:blade.visible});
        blade.traverse(o=>{if(o.isMesh){saved.push({object:o,visible:o.visible,castShadow:o.castShadow});o.castShadow=false;}});
      }
      const samples=axis==='z'?this.bladeSamples(THREE,prop,blades):[];
      this.entries.push({prop,blades,saved,disc,samples,texture:profile.texture,axis,motor:prop.userData.motorIndex??0,
        maxCoverage:profile.maxCoverage,offset:prop.userData.phaseOffset??0});
    }
  }
  bladeSamples(THREE,prop,blades){
    const inverse=prop.matrixWorld.clone().invert(),samples=[];
    for(const blade of blades)blade.traverse(source=>{
      if(!source.isMesh)return;
      const copy=material=>{
        const clone=material.clone();clone.opacity=material.opacity/PLANE_SHUTTER_SAMPLES;
        clone.transparent=true;clone.depthWrite=false;clone.side=THREE.DoubleSide;return clone;
      };
      const material=Array.isArray(source.material)?source.material.map(copy):copy(source.material);
      const mesh=new THREE.InstancedMesh(source.geometry,material,PLANE_SHUTTER_SAMPLES);
      mesh.name='Film_airplane_blade_shutter';mesh.castShadow=false;mesh.receiveShadow=true;
      mesh.frustumCulled=false;mesh.visible=false;mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
      prop.add(mesh);
      samples.push({mesh,source:inverse.clone().multiply(source.matrixWorld),matrix:new THREE.Matrix4()});
    });
    return samples;
  }
  profile(THREE,renderer,prop,blades,radius,axis){
    const scene=new THREE.Scene(),materials=[];
    const inverse=prop.matrixWorld.clone().invert();
    let low=Infinity,high=-Infinity;
    for(const blade of blades)blade.traverse(o=>{
      if(!o.isMesh)return;
      const create=source=>{
        const material=new THREE.MeshBasicMaterial({color:source.color??0xffffff,map:source.map??null,
          transparent:source.transparent,opacity:source.opacity,side:THREE.DoubleSide,
          vertexColors:source.vertexColors,alphaTest:source.alphaTest});
        materials.push(material);return material;
      };
      const mesh=new THREE.Mesh(o.geometry,Array.isArray(o.material)?o.material.map(create):create(o.material));
      mesh.matrixAutoUpdate=false;mesh.matrix.copy(inverse).multiply(o.matrixWorld);scene.add(mesh);
      const position=o.geometry.attributes.position,point=new THREE.Vector3();
      for(let i=0;i<position.count;i++){
        point.fromBufferAttribute(position,i).applyMatrix4(mesh.matrix);
        low=Math.min(low,point[axis]);high=Math.max(high,point[axis]);
      }
    });
    const resolution=512,bins=256,angles=1536,extent=radius*1.025;
    const target=new THREE.WebGLRenderTarget(resolution,resolution,{format:THREE.RGBAFormat,type:THREE.UnsignedByteType});
    target.texture.colorSpace=THREE.SRGBColorSpace;
    const camera=new THREE.OrthographicCamera(-extent,extent,extent,-extent,.01,4);
    if(axis==='y'){camera.position.set(0,1,0);camera.up.set(0,0,-1);}else camera.position.set(0,0,1);
    camera.lookAt(0,0,0);camera.updateMatrixWorld();
    const pixels=new Uint8Array(resolution*resolution*4);
    const old={target:renderer.getRenderTarget(),colour:renderer.getClearColor(new THREE.Color()),
      alpha:renderer.getClearAlpha(),tone:renderer.toneMapping};
    try{
      renderer.setClearColor(0,0);renderer.toneMapping=THREE.NoToneMapping;
      renderer.setRenderTarget(target);renderer.clear();renderer.render(scene,camera);
      renderer.readRenderTargetPixels(target,0,0,resolution,resolution,pixels);
    }finally{
      renderer.setRenderTarget(old.target);renderer.setClearColor(old.colour,old.alpha);renderer.toneMapping=old.tone;
      target.dispose();for(const material of materials)material.dispose();
    }
    const toLinear=Array.from({length:256},(_,i)=>{const c=i/255;return c<=.04045?c/12.92:((c+.055)/1.055)**2.4;});
    const toSrgb=c=>Math.max(0,Math.min(255,Math.round(255*(c<=.0031308?c*12.92:1.055*c**(1/2.4)-.055))));
    const data=new Uint8Array(bins*4);let maxCoverage=0;
    for(let r=0;r<bins;r++){
      const pr=(r+.5)/bins*resolution/2;
      let red=0,green=0,blue=0,alpha=0;
      for(let a=0;a<angles;a++){
        const angle=(a+.5)/angles*Math.PI*2;
        const x=Math.max(0,Math.min(resolution-1,Math.floor(resolution/2+Math.cos(angle)*pr)));
        const y=Math.max(0,Math.min(resolution-1,Math.floor(resolution/2+Math.sin(angle)*pr)));
        const at=(y*resolution+x)*4;
        red+=toLinear[pixels[at]];green+=toLinear[pixels[at+1]];blue+=toLinear[pixels[at+2]];alpha+=pixels[at+3]/255;
      }
      const at=r*4;
      if(alpha){data[at]=toSrgb(Math.min(1,red/alpha));data[at+1]=toSrgb(Math.min(1,green/alpha));data[at+2]=toSrgb(Math.min(1,blue/alpha));}
      data[at+3]=Math.round(alpha/angles*255);maxCoverage=Math.max(maxCoverage,alpha/angles);
    }
    if(maxCoverage<.001)throw Error('Empty film propeller silhouette: '+prop.name);
    const texture=new THREE.DataTexture(data,bins,1,THREE.RGBAFormat);
    texture.colorSpace=THREE.SRGBColorSpace;texture.minFilter=THREE.LinearFilter;texture.magFilter=THREE.LinearFilter;texture.needsUpdate=true;
    return {texture,height:(low+high)/2,maxCoverage};
  }
  update(time,fractions){
    const motion=filmRotorMotion(this.config,time,fractions);
    for(const entry of this.entries){
      const state=motion[entry.motor];
      entry.prop.rotation[entry.axis]=state.phase+entry.offset;
      if(entry.axis==='z'){
        const spinning=state.fraction>0;
        for(const blade of entry.blades)blade.visible=!spinning;
        entry.disc.visible=false;
        for(const sample of entry.samples){
          sample.mesh.visible=spinning;
          for(let i=0;i<PLANE_SHUTTER_SAMPLES;i++){
            const offset=((i+.5)/PLANE_SHUTTER_SAMPLES-.5)*PLANE_SHUTTER_SECONDS*state.angularSpeed;
            sample.matrix.makeRotationZ(offset).multiply(sample.source);sample.mesh.setMatrixAt(i,sample.matrix);
          }
          sample.mesh.instanceMatrix.needsUpdate=true;
        }
        continue;
      }
      const exposed=state.exposureTurns>=1;
      for(const blade of entry.blades)blade.visible=!exposed;
      entry.disc.visible=exposed;
    }
    this.state=motion;return motion;
  }
  diagnostics(){return {shutterSeconds:filmShutterSeconds(this.config),rotors:this.entries.map(entry=>({motor:entry.motor,
    mode:entry.axis==='z'?'sampled-shutter':'rotational-mean',samples:entry.axis==='z'?PLANE_SHUTTER_SAMPLES:0,
    maxCoverage:entry.maxCoverage,exposed:entry.disc.visible||entry.samples.some(s=>s.mesh.visible),...this.state?.[entry.motor]}))};}
  dispose(){
    for(const entry of this.entries){
      for(const saved of entry.saved){saved.object.visible=saved.visible;if(saved.castShadow!==undefined)saved.object.castShadow=saved.castShadow;}
      entry.disc.removeFromParent();entry.disc.geometry.dispose();entry.disc.material.dispose();entry.texture.dispose();
      for(const sample of entry.samples){sample.mesh.removeFromParent();sample.mesh.dispose();
        for(const material of Array.isArray(sample.mesh.material)?sample.mesh.material:[sample.mesh.material])material.dispose();}
    }
    this.entries=[];
  }
}
