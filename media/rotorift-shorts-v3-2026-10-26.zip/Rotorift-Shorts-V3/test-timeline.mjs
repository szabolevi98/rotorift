import test from 'node:test';
import assert from 'node:assert/strict';
import {WIDTH,HEIGHT,FPS,DURATION,shotAt} from './timeline.mjs';
test('portrait short has 1680 unique 60 fps frames and exact five-scene cut boundaries',()=>{
 assert.equal(WIDTH/HEIGHT,9/16);assert.equal(DURATION,28);assert.equal(DURATION*FPS,1680);
 const counts=Array(6).fill(0);
 for(let f=0;f<DURATION*FPS;f++){
  const shot=shotAt(f/FPS);counts[shot.outro?5:shot.chapter]++;
  if(!shot.outro)assert.ok(shot.source>=0&&shot.source<9);
 }
 assert.deepEqual(counts,[300,300,300,300,300,180]);
 for(let i=0;i<5;i++){
  assert.equal(shotAt(i*5).hero,true);assert.equal(shotAt(i*5+1.5).hero,false);
  assert.ok(Math.abs(shotAt(i*5+1/60).source-shotAt(i*5).source-1/60)<1e-12);
 }
 assert.equal(shotAt(25).outro,true);assert.equal(shotAt(28).time,3);
});
test('timeline rejects invalid seeks rather than silently selecting a wrong scene',()=>{
 for(const t of [-.1,28.1,NaN,Infinity])assert.throws(()=>shotAt(t));
});
