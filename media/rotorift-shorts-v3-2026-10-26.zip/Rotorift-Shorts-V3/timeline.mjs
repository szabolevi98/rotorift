export const WIDTH=1080,HEIGHT=1920,FPS=60,DURATION=28;
export const chapters=[
 {map:'APEX CIRCUIT',aircraft:'RIFT X5',headline:['CHASE','THE THRILL.'],hero:.65,fpv:4.7},
 {map:'GROVE',aircraft:'RIFT C3',headline:['FIND','YOUR LINE.'],hero:.9,fpv:4.1},
 {map:'SKYLINE',aircraft:'RIFT AERO 150',headline:['TAKE TO','THE SKIES.'],hero:.8,fpv:4.7},
 {map:'GYMNASIUM',aircraft:'RIFT 65',headline:['SMALL DRONE.','BIG PLAYGROUND.'],hero:.65,fpv:4.7},
 {map:'HARBOR',aircraft:'RIFT R5',headline:['BUILT','FOR SPEED.'],hero:.05,fpv:5},
];
export function shotAt(time){
 if(!Number.isFinite(time)||time<0||time>DURATION)throw Error('Invalid short time');
 if(time>=25)return {outro:true,time:time-25,global:time};
 const chapter=Math.floor(time/5),local=time-chapter*5,hero=local<1.5;
 return {outro:false,chapter,local,hero,source:hero?chapters[chapter].hero+local:chapters[chapter].fpv+local-1.5,global:time};
}
