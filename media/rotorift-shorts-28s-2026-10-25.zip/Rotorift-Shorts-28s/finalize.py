"""Restore the archived master, or assemble freshly rendered portrait segments."""
from pathlib import Path
import argparse, hashlib, json, re, shutil, subprocess
import imageio_ffmpeg

BASE = Path(__file__).resolve().parent
NAME = 'Rotorift-Shorts-English-28s-1080x1920-60fps.mp4'
FF = imageio_ffmpeg.get_ffmpeg_exe()

def ffmpeg(options):
    return subprocess.run([FF, '-hide_banner', *map(str, options)], check=True,
                          capture_output=True, text=True)

def stream_hashes(path):
    return {kind: ffmpeg(['-loglevel', 'error', '-i', path, '-map', stream,
                         '-c', 'copy', '-f', 'hash', '-hash', 'sha256', '-']).stdout.strip().split('=')[-1]
            for kind, stream in [('video', '0:v:0'), ('audio', '0:a:0')]}

def verify(path):
    result = ffmpeg(['-xerror', '-err_detect', 'explode', '-i', path,
                     '-map', '0:v:0', '-map', '0:a:0', '-progress', 'pipe:1', '-f', 'null', '-'])
    frames = re.findall(r'^frame=(\d+)$', result.stdout, re.M)
    assert frames and int(frames[-1]) == 1680, frames
    assert '1080x1920' in result.stderr and '60 fps' in result.stderr, result.stderr
    assert 'Duration: 00:00:28.00' in result.stderr, result.stderr
    assert 'yuv420p(tv, bt709, progressive)' in result.stderr, result.stderr
    assert '48000 Hz, stereo' in result.stderr, result.stderr
    return {'frames': 1680, 'duration_seconds': 28, 'width': 1080, 'height': 1920,
            'fps': 60, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
            'bytes': path.stat().st_size, 'encoded_stream_sha256': stream_hashes(path),
            'decode': 'H.264 video and AAC audio decoded fully with -xerror -err_detect explode'}

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--fresh', action='store_true', help='assemble media/segment-0..5.mp4 and score.wav')
    parser.add_argument('--output', type=Path, default=BASE/'generated'/NAME)
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    if args.fresh:
        clips = [BASE/'media'/f'segment-{i}.mp4' for i in range(6)]
        for clip in clips:
            assert clip.is_file(), clip
        concat = BASE/'media'/'concat.txt'
        concat.write_text(''.join("file '"+clip.as_posix()+"'\n" for clip in clips), encoding='utf8')
        ffmpeg(['-y', '-loglevel', 'warning', '-f', 'concat', '-safe', '0', '-i', concat,
                '-i', BASE/'score.wav', '-map', '0:v:0', '-map', '1:a:0', '-c:v', 'copy',
                '-bsf:v', 'h264_metadata=colour_primaries=1:transfer_characteristics=1:matrix_coefficients=1:video_full_range_flag=0',
                '-af', 'loudnorm=I=-16:TP=-1:LRA=9', '-c:a', 'aac', '-b:a', '192k',
                '-ar', '48000', '-t', '28', '-movflags', '+faststart',
                '-metadata', 'title=Rotorift | Fly free | Shorts',
                '-metadata', 'comment=Scripted cinematic captured from the Rotorift game renderer. Original synthesized music and sound design.', args.output])
    else:
        source = BASE/'approved'/NAME
        assert source.is_file(), 'No archived master. Render segments and use --fresh.'
        shutil.copy2(source, args.output)
    result = verify(args.output)
    if not args.fresh:
        expected = json.loads((BASE/'manifest.json').read_text(encoding='utf8'))['approved']
        assert result['sha256'] == expected['sha256'], 'Master file differs'
        assert result['encoded_stream_sha256'] == expected['encoded_stream_sha256'], 'Encoded streams differ'
    args.output.with_suffix('.verification.json').write_text(json.dumps(result, indent=2), encoding='utf8')
    print(json.dumps(result, indent=2))
    print(args.output)

if __name__ == '__main__':
    main()
