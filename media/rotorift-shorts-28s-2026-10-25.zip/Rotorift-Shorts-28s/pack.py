"""Build and integrity-check the self-contained Shorts archive."""
from pathlib import Path
import argparse, hashlib, json, zipfile
from finalize import NAME, verify

BASE = Path(__file__).resolve().parent
SOURCES = ['README.md', 'config.mjs', 'server.mjs', 'shorts.html', 'shorts.js',
           'scene.js', 'timeline.mjs', 'propeller-exposure.js', 'render.mjs',
           'finalize.py', 'pack.py', 'score.py', 'score.wav', 'package.json',
           'package-lock.json', 'requirements.txt', 'test-timeline.mjs',
           'preview-checks.json', 'audio-check.txt', 'final-contact.jpg']
ROOT = 'Rotorift-Shorts-28s/'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--master', type=Path, default=BASE/'approved'/NAME)
    parser.add_argument('--destination', type=Path, default=BASE/'rotorift-shorts-28s-2026-10-25.zip')
    args = parser.parse_args()
    approved = verify(args.master)
    payload = {name: (BASE/name).read_bytes() for name in SOURCES}
    payload['approved/'+NAME] = args.master.read_bytes()
    payload['approved/'+Path(NAME).with_suffix('.verification.json').name] = json.dumps(approved, indent=2).encode()
    manifest = {'created': '2026-10-25', 'game_commit': '6673c7d09759d574858e68377f3de02541d507b6',
                'game_repo': 'https://github.com/szabolevi98/rotorift.git',
                'approved_file': 'approved/'+NAME, 'approved': approved,
                'files': {name: {'bytes': len(data), 'sha256': sha(data)} for name, data in payload.items()}}
    payload['manifest.json'] = json.dumps(manifest, indent=2).encode()
    args.destination.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(args.destination, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for name, data in payload.items():
            archive.writestr(ROOT+name, data)
    with zipfile.ZipFile(args.destination) as archive:
        assert archive.testzip() is None, 'ZIP CRC failure'
        for name, expected in manifest['files'].items():
            actual = archive.read(ROOT+name)
            assert len(actual) == expected['bytes'] and sha(actual) == expected['sha256'], name
    print(json.dumps({'archive': str(args.destination), 'bytes': args.destination.stat().st_size,
                      'sha256': sha(args.destination.read_bytes()), 'members': len(payload),
                      'verification': 'All ZIP CRC and SHA-256 checks passed'}, indent=2))

if __name__ == '__main__':
    main()
