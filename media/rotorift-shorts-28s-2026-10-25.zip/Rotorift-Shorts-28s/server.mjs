import http from 'node:http';
import {readFile} from 'node:fs/promises';
import {pathToFileURL} from 'node:url';
import {repoRoot} from './config.mjs';
const {serveStatic}=await import(pathToFileURL(repoRoot+'/server/static.js'));
const {loadCatalog}=await import(pathToFileURL(repoRoot+'/server/catalog.js'));
const catalog=await loadCatalog();
const localFiles=new Map([['/shorts','shorts.html'],['/scene.js','scene.js'],['/shorts.js','shorts.js'],['/timeline.mjs','timeline.mjs'],['/propeller-exposure.js','propeller-exposure.js']]);
http.createServer(async(req,res)=>{
 try{
  const url=new URL(req.url,'http://127.0.0.1:3199');
  if(localFiles.has(url.pathname)){
   const file=localFiles.get(url.pathname);res.setHeader('Content-Type',file.endsWith('.html')?'text/html':'text/javascript');
   res.setHeader('Cache-Control','no-store');res.end(await readFile(new URL(file,import.meta.url)));return;
  }
  if(url.pathname==='/api/catalog'){res.setHeader('Content-Type','application/json');res.end(JSON.stringify(catalog));return;}
  if(await serveStatic(req,res,url))return;res.writeHead(404).end();
 }catch(error){console.error(error);res.writeHead(500).end(error.message);}
}).listen(3199,'127.0.0.1',()=>console.log('Shorts renderer: http://127.0.0.1:3199/shorts | '+repoRoot));
