import {chromium} from 'playwright-core';
import {mkdir,writeFile,unlink} from 'node:fs/promises';
import {spawnSync} from 'node:child_process';
import {base,chrome,chromeArgs,url} from './config.mjs';
import {WIDTH,HEIGHT,FPS,DURATION} from './timeline.mjs';
const preview=process.argv.includes('--preview');
const browser=await chromium.launch({executablePath:chrome,headless:true,args:chromeArgs});
try{
 const page=await browser.newPage({viewport:{width:WIDTH,height:HEIGHT},deviceScaleFactor:1});
 const cdp=await page.context().newCDPSession(page);
 page.on('pageerror',error=>{throw error;});
 await page.goto(url);await page.waitForFunction(()=>window.shortReady,undefined,{timeout:120000});
 console.log('SHORT',await page.evaluate(()=>window.shortInfo));
 await mkdir(base+'/previews',{recursive:true});await mkdir(base+'/media',{recursive:true});
 const capture=async path=>{
  const image=await cdp.send('Page.captureScreenshot',{format:'png',fromSurface:true,captureBeyondViewport:false,optimizeForSpeed:true});
  await writeFile(path,Buffer.from(image.data,'base64'));
 };
 if(preview){
  const states=[];
  for(const time of [0,.45,1.35,1.5,3.5,4.8,5.45,6.35,6.5,8.5,9.8,10.45,11.35,11.5,13.5,14.8,15.45,16.35,16.5,18.5,19.8,20.45,21.35,21.5,23.5,24.8,25.5,27.5]){
   await page.evaluate(t=>window.renderShort(t),time);
   const state=await page.evaluate(async()=>{
    const shot=window.shortContext,result={...shot};if(shot.outro)return result;
    result.exposure=window.filmRotorExposure;
    result.attitude=window.filmAttitude;
    if(shot.hero){
     const THREE=await import('/vendor/three/build/three.module.js'),d=window.filmDebug,box=new THREE.Box3().setFromObject(d.model),points=[];
     for(const x of [box.min.x,box.max.x])for(const y of [box.min.y,box.max.y])for(const z of [box.min.z,box.max.z]){
      const p=new THREE.Vector3(x,y,z).project(d.camera);points.push([(p.x+1)*540,(1-p.y)*960]);
     }
     result.bounds={left:Math.min(...points.map(p=>p[0])),right:Math.max(...points.map(p=>p[0])),top:Math.min(...points.map(p=>p[1])),bottom:Math.max(...points.map(p=>p[1]))};
    }
    return result;
   });
   await capture(`${base}/previews/frame-${time}.png`);states.push(state);console.log('PREVIEW',time,JSON.stringify(state.bounds??{}));
  }
  await writeFile(base+'/attitude-samples.json',JSON.stringify(await page.evaluate(()=>[0,1,2,3,4].map(i=>window.filmAttitudeSamples(i))),null,2));
  await writeFile(base+'/preview-checks.json',JSON.stringify(states,null,2));
 }else{
  for(let segment=0;segment<6;segment++){
   const start=segment*5,count=(segment===5?3:5)*FPS,dir=base+`/frames/segment-${segment}`;
   await mkdir(dir,{recursive:true});
   for(let frame=0;frame<count;frame++){
    await page.evaluate(t=>window.renderShort(t),start+frame/FPS);
    await capture(`${dir}/frame-${String(frame).padStart(4,'0')}.png`);
    if(frame%60===0)console.log('FRAME',segment,frame);
   }
   const encoder=spawnSync(process.env.FILM_FFMPEG,['-y','-hide_banner','-loglevel','warning','-xerror','-err_detect','explode','-framerate',String(FPS),'-i',dir+'/frame-%04d.png','-frames:v',String(count),'-an','-vf','scale=in_range=full:out_range=limited:out_color_matrix=bt709,format=yuv420p,setsar=1','-c:v','libx264','-preset','medium',...(segment===5?['-tune','grain']:[]),'-crf',segment===5?'12':'17','-profile:v','high','-level:v','4.2','-color_range','tv','-colorspace','bt709','-color_primaries','bt709','-color_trc','bt709','-video_track_timescale','15360','-movflags','+faststart',base+`/media/segment-${segment}.mp4`],{windowsHide:true,stdio:'inherit'});
   if(encoder.error)throw encoder.error;if(encoder.status)throw Error('Encoder failed: '+segment);
   if(!process.argv.includes('--keep-frames'))for(let f=0;f<count;f++)await unlink(`${dir}/frame-${String(f).padStart(4,'0')}.png`);
   console.log('DONE',segment,count);
  }
 }
}finally{await browser.close();}
