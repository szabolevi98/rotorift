// Film-only attitude estimate. Positions, camera paths and game physics stay
// in their original modules. Positive pitch means nose down.
export const GRAVITY=9.81;
export const PITCH_LIMITS={min:-35*Math.PI/180,max:60*Math.PI/180};
export function pitchForMotion(velocity,acceleration,heading,config){
  const speed=Math.hypot(...velocity);
  const drag=(config.linearDrag+config.quadraticDrag*speed)/config.massKg;
  const horizontal=Math.hypot(heading[0],heading[2]);
  if(horizontal<1e-9)return 0;
  const forwardForce=((acceleration[0]+drag*velocity[0])*heading[0]
    +(acceleration[2]+drag*velocity[2])*heading[2])/horizontal;
  const verticalForce=Math.max(GRAVITY*.25,GRAVITY+acceleration[1]+drag*velocity[1]);
  const angle=Math.atan2(forwardForce,verticalForce);
  // A soft cinematic limit keeps the approved close camera readable, even
  // where the scripted path speed would imply an almost vertical racing quad.
  const limit=angle<0?-PITCH_LIMITS.min:PITCH_LIMITS.max;
  return limit*Math.tanh(angle/limit);
}
export function sampleMotion(positions,hz){
  const difference=(values,radius)=>values.map((_,i)=>{
    const a=Math.max(0,i-radius),b=Math.min(values.length-1,i+radius);
    return values[b].map((value,axis)=>(value-values[a][axis])*hz/(b-a));
  });
  const velocity=difference(positions,12);
  return {velocity,acceleration:difference(velocity,18)};
}
