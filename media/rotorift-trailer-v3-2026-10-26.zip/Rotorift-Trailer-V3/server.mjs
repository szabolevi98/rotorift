import http from 'node:http';
import {readFile} from 'node:fs/promises';
import {pathToFileURL} from 'node:url';
import {repoRoot} from './config.mjs';
const {serveStatic}=await import(pathToFileURL(repoRoot+'/server/static.js'));
const {loadCatalog}=await import(pathToFileURL(repoRoot+'/server/catalog.js'));
const catalog=await loadCatalog();
http.createServer(async(req,res)=>{
  try{
    const url=new URL(req.url,'http://127.0.0.1:3196');
    if(url.pathname==='/flight-attitude.mjs'){res.setHeader('Content-Type','text/javascript');res.end(await readFile(new URL('./flight-attitude.mjs',import.meta.url)));return;}
    if(url.pathname==='/film'||url.pathname==='/film.js'||url.pathname==='/propeller-exposure.js'){
      const js=url.pathname.endsWith('.js');
      res.setHeader('Content-Type',js?'text/javascript':'text/html');
      res.end(await readFile(new URL(url.pathname==='/propeller-exposure.js'?'./propeller-exposure.js':js?'./trailer.js':'./trailer.html',import.meta.url)));return;
    }
    if(url.pathname==='/api/catalog'){res.setHeader('Content-Type','application/json');res.end(JSON.stringify(catalog));return;}
    if(await serveStatic(req,res,url))return;
    res.writeHead(404).end();
  }catch(error){console.error(error);res.writeHead(500).end(error.message);}
}).listen(3196,'127.0.0.1',()=>console.log('Renderer: http://127.0.0.1:3196/film | Repo: '+repoRoot));
