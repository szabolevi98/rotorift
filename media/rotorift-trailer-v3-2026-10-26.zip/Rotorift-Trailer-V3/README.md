# Rotorift – angol trailer V3, javított dróndőlés

Kiadás: 2026-10-26.

## Időzítés és formátum

49 s, 1920×1080, 16:9, 60 fps, 2940 képkocka.
Öt kilencmásodperces jelenet: Apex/X5, Grove/C3, Skyline/Aero 150,
Gymnasium/Rift 65, Harbor/R5. A zárókép 45–49 s.

A helyi szerver: http://127.0.0.1:3196/film .
A 45–49 s közötti zárókép a V2 veszteségmentesen megőrzött kódolt klipje:
`reference/end.mp4`; friss rajzolása opcionális: `node render-endcard.mjs`.
A `finalize.py --fresh` az új `media/end.mp4` fájlt használja, ha az létezik,
különben a megőrzött referenciát. A `render.mjs --chapter=0` csak az első
jelenetet rendereli. A kép H.264 High Level 4.2, yuv420p, BT.709 limited,
CRF 17/medium; az eredeti zárókép CRF 12/grain. A `--fresh` összeállításhoz
mind az öt scene klip kell. Az `assemble.py` korábbi folyamata helyett
most a mellékelt `finalize.py` az aktuális belépőpont.

## Mi változott?

A korábbi fix, kb. 6,3°-os előredőlés helyett a drón testdőlése a meglévő,
240 Hz-en mintavételezett és simított útvonal sebességéből és gyorsulásából
számolódik. A `flight-attitude.mjs` a katalógus szerinti tömeget és a játék
lineáris/négyzetes légellenállási együtthatóit használja.

A várt tolóerő gyorsulása: `útvonal-gyorsulás + légellenállás/tömeg + gravitáció`.
Ennek haladási és függőleges összetevőjéből adódik a bólintás. A filmszerű
közeli kamera miatt a számított szög sima `tanh` korlátozást kap: előre 60°,
hátra 35° a lágy határ, majd 0,25 s-os Gauss-simítás következik. A test
bólintása a vízszintes irányhoz képest értendő, nem adódik hozzá még egyszer
az útvonal emelkedési szöge. Erős fékezést a számítás hátradőléssel is tud
megjeleníteni; a jelenlegi vágásban a drónok végig pozitív előredőlésűek.

Ez fizikával indokolt, lágyan korlátozott filmes közelítés. A film továbbra is
tervezett kamerás animáció a játék valódi modelljeivel és pályáival, nem
végigjátszott fizikai repülés vagy generatív videó.

A teljes kilencmásodperces forrásjelenetekben mért előredőlés:

| Drón | Szögtartomány |
| --- | --- |
| Rift X5 | 42,25–52,06° |
| Rift C3 | 20,79–34,07° |
| Rift 65 | 6,78–13,18° |
| Rift R5 | 47,27–52,76° |

A simított bólintás legnagyobb változása 60 fps-en kb. 0,202°/képkocka.
A geometria, útvonal, kamera, autószínek, angol feliratok, időzítés és
repülőmodell megmaradtak. Az X5 a kék autót követi, az elöl levő autó narancs.
A repülő továbbra is a 1500 mm-es Aero 150. A légcsavarok V2 elmosása maradt:
kvadok 1/120 s, repülő 32 mintás 1/2000 s expozíció, látható lapátívekkel.
A felvétel utáni ellenőrzés a teljes H.264 és AAC sávot szigorúan dekódolja.

## Rögzített forrás és környezet

- Játékrepo: https://github.com/szabolevi98/rotorift.git
- Renderhez használt játék HEAD: `e2328d0bb978a247a9c5c67f944479367624e478`.
- A játék fájljait ez a javítás nem módosítja; az egyéni canopy-lab módosítás
  nem része a filmnek.
- Windows, Node 24.19.0, Python 3.10.11, Chrome 156.0.8078.47, D3D11/WebGL.
- Playwright Core 1.64.1, Three.js 0.169.0, FFmpeg 7.1 / imageio-ffmpeg 0.6.0.
- A többi Python-verzió a `requirements.txt`, a Node lock a `package-lock.json`.

## A kész videó pontos visszaállítása

A ZIP kibontott gyökérmappájából:

```powershell
python -m pip install imageio-ffmpeg==0.6.0
python finalize.py
```

A `generated/` mappába másolt MP4 bájtra megegyezik az `approved/` mesterrel.
A program teljes dekódolást és SHA-256-ellenőrzést végez a manifest alapján;
a kódolt H.264 és AAC tartalom külön lenyomatát is összehasonlítja.
Ehhez játék, Chrome és adatbázis nem kell.

## Teljes új render

Készíts külön forrásklónt, a checkout parancsot ne saját módosításokat
őrző munkamappán futtasd:

```powershell
git clone https://github.com/szabolevi98/rotorift.git D:\rotorift-film-source
git -C D:\rotorift-film-source checkout e2328d0bb978a247a9c5c67f944479367624e478
npm ci --prefix D:\rotorift-film-source
```

A kibontott filmforrás mappájában:

```powershell
npm ci
python -m pip install -r requirements.txt
node --test test-flight-attitude.mjs
$env:ROTORIFT_ROOT = 'D:\rotorift-film-source'
$env:CHROME_PATH = 'C:\Program Files\Google\Chrome\Application\chrome.exe'
node server.mjs
```

A szerver maradjon futva; második PowerShell ablakban ugyanabban a mappában:

```powershell
$env:CHROME_PATH = 'C:\Program Files\Google\Chrome\Application\chrome.exe'
$env:FILM_FFMPEG = python -c "import imageio_ffmpeg; print(imageio_ffmpeg.get_ffmpeg_exe())"
node render.mjs
python finalize.py --fresh
```

A szerver csak localhoston szolgál ki, nincs adatbázis vagy éles deploy.
Leállítás: Ctrl+C. A PNG képkockákat a renderer az adott rész sikeres
kódolása után törli; a `--keep-frames` kapcsolóval megőrizhetők. Áramszünet
után a render parancs újraindítható, és újra előállítja a részeket.

A végső összerakás a képet és az eredeti AAC hangot újrakódolás nélkül másolja.
A H.264 BT.709 primaries/transfer/matrix jelöléseit a `h264_metadata` szűrő
rögzíti. A friss GPU-render eltérhet driver-, Chrome- vagy kódolóverzió miatt;
a bájtpontos visszaállításhoz az `approved/` példány használható.

## Hang, csomag és ellenőrzések

A `reference/audio.m4a` az előző végleges videó eredeti AAC tartalma, másolva.
A teljes hangsáv külön streamhash-e egyezik az előző kiadáséval. A
`score.wav` és `score.py` a hang módosításához is megmaradt. A
`python score.py` újraszintetizál, a `python finalize.py --fresh --rescore`
normalizálja és újrakódolja a módosított WAV-ot (-16 LUFS, -1 dBTP cél,
192 kbit/s AAC, stereo 48 kHz).

A ZIP tartalmazza a kész MP4-et, a teljes renderforrást, az eredeti WAV/AAC
hangot, a lockfájlokat, ezt az MD-t, a tesztet és az ellenőrzési adatokat.
A manifest minden megőrzött fájl SHA-256 lenyomatát és méretét rögzíti.
A PNG köztes képkockák és a node_modules nincsenek a csomagban.
A `pack.py --master <MP4> --destination <ZIP>` újra csomagolja a kiadást,
és minden ZIP-bejegyzést CRC- és SHA-256-ellenőrzéssel visszaolvas.
A korábbi videók és az OG-borító változatlanul a korábbi archívumokban maradnak.
